from __future__ import annotations

import math
from typing import Iterable

import numpy as np
from scipy.spatial import cKDTree


SQRT3_OVER_2 = math.sqrt(3.0) / 2.0


def voxel_to_world(indices: np.ndarray, resolution: float, origin: np.ndarray) -> np.ndarray:
    return origin + indices.astype(np.float32) * resolution


def world_to_voxel(point: np.ndarray, resolution: float, origin: np.ndarray) -> np.ndarray:
    return np.rint((point - origin) / resolution).astype(int)


def quantize_radius(radius: float, esdf_value: float, clearance: float, step: float) -> float:
    capped = max(clearance, min(radius, esdf_value))
    n_steps = math.floor((capped - clearance) / step + 1e-8)
    return clearance + max(0, n_steps) * step


def stable_edge(a: int, b: int) -> tuple[int, int]:
    return (a, b) if a <= b else (b, a)


def sample_polyline(points: np.ndarray, step: float) -> np.ndarray:
    if len(points) < 2:
        return points.copy()
    sampled: list[np.ndarray] = [points[0]]
    for left, right in zip(points[:-1], points[1:]):
        delta = right - left
        length = float(np.linalg.norm(delta))
        if length == 0:
            continue
        n = max(1, int(math.ceil(length / step)))
        for idx in range(1, n + 1):
            sampled.append(left + delta * (idx / n))
    return np.asarray(sampled, dtype=np.float32)


def build_kdtree(points: np.ndarray) -> tuple[cKDTree, np.ndarray]:
    return cKDTree(points.astype(np.float32)), points.astype(np.float32)


def nearest_point(query: np.ndarray, tree: cKDTree, points: np.ndarray) -> np.ndarray:
    _, idx = tree.query(query.astype(np.float32))
    return points[int(idx)].copy()


def gf2_rank(matrix: np.ndarray) -> int:
    work = np.asarray(matrix, dtype=np.uint8).copy()
    rows, cols = work.shape
    pivot_row = 0
    rank = 0
    for col in range(cols):
        pivot = None
        for row in range(pivot_row, rows):
            if work[row, col]:
                pivot = row
                break
        if pivot is None:
            continue
        if pivot != pivot_row:
            work[[pivot_row, pivot]] = work[[pivot, pivot_row]]
        for row in range(rows):
            if row != pivot_row and work[row, col]:
                work[row] ^= work[pivot_row]
        pivot_row += 1
        rank += 1
        if pivot_row == rows:
            break
    return rank


def gf2_contains_column_space(matrix: np.ndarray, column: np.ndarray) -> bool:
    if matrix.size == 0:
        return not np.any(column)
    left_rank = gf2_rank(matrix)
    augmented = np.concatenate([matrix, column[:, None].astype(np.uint8)], axis=1)
    return gf2_rank(augmented) == left_rank


def cycle_edge_vector(edges: list[tuple[int, int]], edge_index: dict[tuple[int, int], int]) -> np.ndarray:
    vec = np.zeros(len(edge_index), dtype=np.uint8)
    for edge in edges:
        vec[edge_index[stable_edge(*edge)]] ^= 1
    return vec


def majority_label(labels: Iterable[int]) -> int:
    counts: dict[int, int] = {}
    for label in labels:
        if label <= 0:
            continue
        counts[label] = counts.get(label, 0) + 1
    if not counts:
        return 0
    return max(counts.items(), key=lambda item: item[1])[0]


def line_plane_crossing(segment_start: np.ndarray, segment_end: np.ndarray, surface: np.ndarray) -> int:
    point = surface[0]
    normal = surface[1]
    radius = float(surface[2, 0]) if surface.shape[0] > 2 else math.inf
    signed_start = float(np.dot(segment_start - point, normal))
    signed_end = float(np.dot(segment_end - point, normal))
    if signed_start == 0.0 and signed_end == 0.0:
        return 0
    if signed_start * signed_end > 0.0:
        return 0
    denom = signed_end - signed_start
    if denom == 0.0:
        return 0
    t = -signed_start / denom
    if t < 0.0 or t > 1.0:
        return 0
    hit = segment_start + t * (segment_end - segment_start)
    if np.linalg.norm(hit - point) > radius:
        return 0
    return 1 if signed_end > signed_start else -1


def accumulate_signature(polyline: np.ndarray, surfaces: list[np.ndarray]) -> tuple[int, ...]:
    signature = [0 for _ in surfaces]
    for left, right in zip(polyline[:-1], polyline[1:]):
        for idx, surface in enumerate(surfaces):
            signature[idx] += line_plane_crossing(left, right, surface)
    return tuple(signature)
