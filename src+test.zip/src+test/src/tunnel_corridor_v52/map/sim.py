from __future__ import annotations

from dataclasses import dataclass

import networkx as nx
import numpy as np
from scipy import ndimage as ndi

from ..models import Map3D


@dataclass(frozen=True)
class SceneSpec:
    name: str
    nodes: dict[str, np.ndarray]
    edges: list[tuple[str, str]]
    portals: list[tuple[str, str]]
    room_radii: dict[str, float]
    tube_radius: float


def available_scenes(grid_shape: tuple[int, int, int] = (48, 48, 48)) -> list[str]:
    return sorted(_scene_specs(grid_shape))


def _fractional_point(grid_shape: tuple[int, int, int], fx: float, fy: float, fz: float) -> np.ndarray:
    dims = np.asarray(grid_shape, dtype=np.float32) - 1.0
    return np.asarray([fx, fy, fz], dtype=np.float32) * dims


def _scene_specs(grid_shape: tuple[int, int, int]) -> dict[str, SceneSpec]:
    return {
        "single_tunnel": SceneSpec(
            name="single_tunnel",
            nodes={
                "S": _fractional_point(grid_shape, 0.12, 0.50, 0.50),
                "M": _fractional_point(grid_shape, 0.50, 0.50, 0.50),
                "G": _fractional_point(grid_shape, 0.88, 0.50, 0.50),
            },
            edges=[("S", "M"), ("M", "G")],
            portals=[("S", "G")],
            room_radii={},
            tube_radius=3.2,
        ),
        "double_tunnel": SceneSpec(
            name="double_tunnel",
            nodes={
                "L": _fractional_point(grid_shape, 0.12, 0.50, 0.50),
                "TU": _fractional_point(grid_shape, 0.32, 0.68, 0.50),
                "TR": _fractional_point(grid_shape, 0.68, 0.68, 0.50),
                "R": _fractional_point(grid_shape, 0.88, 0.50, 0.50),
                "BL": _fractional_point(grid_shape, 0.32, 0.32, 0.50),
                "BR": _fractional_point(grid_shape, 0.68, 0.32, 0.50),
            },
            edges=[("L", "TU"), ("TU", "TR"), ("TR", "R"), ("L", "BL"), ("BL", "BR"), ("BR", "R")],
            portals=[("L", "R")],
            room_radii={},
            tube_radius=3.0,
        ),
        "tunnel_cavity": SceneSpec(
            name="tunnel_cavity",
            nodes={
                "S": _fractional_point(grid_shape, 0.12, 0.50, 0.50),
                "M": _fractional_point(grid_shape, 0.45, 0.50, 0.50),
                "C": _fractional_point(grid_shape, 0.72, 0.50, 0.50),
            },
            edges=[("S", "M"), ("M", "C")],
            portals=[("S", "C")],
            room_radii={"C": 6.5},
            tube_radius=3.0,
        ),
        "multi_room_loop": SceneSpec(
            name="multi_room_loop",
            nodes={
                "L": _fractional_point(grid_shape, 0.12, 0.50, 0.50),
                "A": _fractional_point(grid_shape, 0.30, 0.72, 0.50),
                "B": _fractional_point(grid_shape, 0.70, 0.72, 0.50),
                "R": _fractional_point(grid_shape, 0.88, 0.50, 0.50),
                "C": _fractional_point(grid_shape, 0.70, 0.28, 0.50),
                "D": _fractional_point(grid_shape, 0.30, 0.28, 0.50),
            },
            edges=[("L", "A"), ("A", "B"), ("B", "R"), ("L", "D"), ("D", "C"), ("C", "R")],
            portals=[("L", "R")],
            room_radii={"A": 4.5, "B": 4.5, "C": 4.5, "D": 4.5},
            tube_radius=2.8,
        ),
        "double_loop": SceneSpec(
            name="double_loop",
            nodes={
                "L": _fractional_point(grid_shape, 0.08, 0.72, 0.50),
                "A": _fractional_point(grid_shape, 0.22, 0.72, 0.50),
                "B": _fractional_point(grid_shape, 0.46, 0.72, 0.50),
                "C": _fractional_point(grid_shape, 0.70, 0.72, 0.50),
                "R": _fractional_point(grid_shape, 0.92, 0.72, 0.50),
                "D": _fractional_point(grid_shape, 0.22, 0.30, 0.50),
                "E": _fractional_point(grid_shape, 0.46, 0.30, 0.50),
                "F": _fractional_point(grid_shape, 0.70, 0.30, 0.50),
            },
            edges=[
                ("L", "A"),
                ("A", "B"),
                ("B", "C"),
                ("C", "R"),
                ("A", "D"),
                ("B", "E"),
                ("C", "F"),
                ("D", "E"),
                ("E", "F"),
            ],
            portals=[("L", "R")],
            room_radii={"A": 4.0, "B": 4.0, "C": 4.0, "D": 4.0, "E": 4.0, "F": 4.0},
            tube_radius=2.6,
        ),
        "false_merge_trap": SceneSpec(
            name="false_merge_trap",
            nodes={
                "US": _fractional_point(grid_shape, 0.14, 0.62, 0.50),
                "UM": _fractional_point(grid_shape, 0.50, 0.62, 0.50),
                "UG": _fractional_point(grid_shape, 0.86, 0.62, 0.50),
                "LS": _fractional_point(grid_shape, 0.14, 0.38, 0.50),
                "LM": _fractional_point(grid_shape, 0.50, 0.38, 0.50),
                "LG": _fractional_point(grid_shape, 0.86, 0.38, 0.50),
            },
            edges=[("US", "UM"), ("UM", "UG"), ("LS", "LM"), ("LM", "LG")],
            portals=[("US", "UG"), ("LS", "LG")],
            room_radii={},
            tube_radius=3.2,
        ),
    }


def _grid_world(shape: tuple[int, int, int], resolution: float) -> np.ndarray:
    mesh = np.meshgrid(
        np.arange(shape[0], dtype=np.float32),
        np.arange(shape[1], dtype=np.float32),
        np.arange(shape[2], dtype=np.float32),
        indexing="ij",
    )
    return np.stack(mesh, axis=-1) * resolution


def _distance_to_segment(points: np.ndarray, start: np.ndarray, end: np.ndarray) -> np.ndarray:
    delta = end - start
    denom = float(np.dot(delta, delta))
    if denom == 0.0:
        return np.linalg.norm(points - start, axis=-1)
    t = np.clip(np.sum((points - start) * delta, axis=-1) / denom, 0.0, 1.0)
    projection = start + t[..., None] * delta
    return np.linalg.norm(points - projection, axis=-1)


def _carve_capsule(free_mask: np.ndarray, world: np.ndarray, start: np.ndarray, end: np.ndarray, radius: float) -> None:
    distances = _distance_to_segment(world, start, end)
    free_mask |= distances <= radius


def _carve_sphere(free_mask: np.ndarray, world: np.ndarray, center: np.ndarray, radius: float) -> None:
    free_mask |= np.linalg.norm(world - center, axis=-1) <= radius


def _graph_metadata(spec: SceneSpec) -> dict[str, object]:
    graph = nx.Graph()
    for name, point in spec.nodes.items():
        graph.add_node(name, point=point.astype(np.float32))
    graph.add_edges_from(spec.edges)
    return {
        "graph": graph,
        "nodes": {name: point.astype(np.float32) for name, point in spec.nodes.items()},
        "edges": list(spec.edges),
        "portals": list(spec.portals),
    }


def generate_scene(
    scene_name: str,
    grid_shape: tuple[int, int, int] = (48, 48, 48),
    resolution: float = 1.0,
    clearance: float = 2.0,
) -> Map3D:
    specs = _scene_specs(grid_shape)
    if scene_name not in specs:
        supported = ", ".join(sorted(specs))
        raise ValueError(f"Unsupported scene '{scene_name}'. Supported scenes: {supported}")

    spec = specs[scene_name]
    world = _grid_world(grid_shape, resolution)
    free_mask = np.zeros(grid_shape, dtype=bool)
    for left, right in spec.edges:
        _carve_capsule(free_mask, world, spec.nodes[left], spec.nodes[right], spec.tube_radius)
    for node_name, room_radius in spec.room_radii.items():
        _carve_sphere(free_mask, world, spec.nodes[node_name], room_radius)

    occupancy = ~free_mask
    esdf = ndi.distance_transform_edt(free_mask, sampling=resolution).astype(np.float32)
    graph_info = _graph_metadata(spec)
    graph: nx.Graph = graph_info["graph"]  # type: ignore[assignment]
    cycle_count = graph.number_of_edges() - graph.number_of_nodes() + nx.number_connected_components(graph)
    component_count = nx.number_connected_components(graph)
    metadata = {
        "scene_name": scene_name,
        "graph_nodes": graph_info["nodes"],
        "graph_edges": graph_info["edges"],
        "portal_pairs": graph_info["portals"],
        "room_radii": dict(spec.room_radii),
        "tube_radius": spec.tube_radius,
        "beta_hint": (component_count, cycle_count),
        "audit_start": spec.nodes[spec.portals[0][0]].astype(np.float32),
        "audit_goal": spec.nodes[spec.portals[0][1]].astype(np.float32),
    }
    return Map3D(
        esdf_grid=esdf,
        resolution=resolution,
        origin=np.zeros(3, dtype=np.float32),
        clearance_threshold=clearance,
        safety_margin=0.1 * resolution,
        occupancy_grid=occupancy.astype(bool),
        free_mask=free_mask.astype(bool),
        metadata=metadata,
    )
