from __future__ import annotations

import os
from itertools import islice

import networkx as nx
import numpy as np

os.environ.setdefault("SYMPY_GROUND_TYPES", "python")

from sympy import Matrix

from ..graph.complex import construct_full_nerve, cycle_is_nontrivial, safe_radius
from ..graph.query import chain_signature
from ..models import Map3D, RegisteredPathRealization, SphereNode, TopoReference, WitnessRealization
from ..utils import accumulate_signature, build_kdtree, majority_label, nearest_point, quantize_radius, sample_polyline, stable_edge, world_to_voxel
from .initial import compute_candidate_sets


def _reindex_spheres(spheres: list[SphereNode]) -> list[SphereNode]:
    return [
        SphereNode(id=idx, center=sphere.center.copy(), radius=float(sphere.radius), level=sphere.level, region_id=sphere.region_id)
        for idx, sphere in enumerate(spheres)
    ]


def _sphere_contains(point: np.ndarray, sphere: SphereNode, radius: float) -> bool:
    return float(np.linalg.norm(point - sphere.center)) <= radius


def _nearest_covering_sphere(point: np.ndarray, spheres: list[SphereNode], map3d: Map3D, use_safe: bool) -> int | None:
    chosen: tuple[float, int] | None = None
    for sphere in spheres:
        radius = safe_radius(map3d, sphere) if use_safe else sphere.radius
        if _sphere_contains(point, sphere, radius):
            distance = float(np.linalg.norm(point - sphere.center))
            if chosen is None or distance < chosen[0]:
                chosen = (distance, sphere.id)
    return None if chosen is None else chosen[1]


def _sphere_majority_label(map3d: Map3D, voxel_ids: set[int]) -> int:
    labels = map3d.metadata.get("component_labels")
    if labels is None or not voxel_ids:
        return 0
    coords = np.asarray(np.unravel_index(np.asarray(sorted(voxel_ids), dtype=np.int64), labels.shape)).T
    values = [int(labels[tuple(coord)]) for coord in coords]
    return majority_label(values)


def _insert_projected_sphere(
    point: np.ndarray,
    level: str,
    spheres: list[SphereNode],
    map3d: Map3D,
    candidate_points: np.ndarray,
    tree,
    radius_step: float,
) -> int | None:
    return _insert_projected_sphere_with_anchors(
        point,
        level,
        spheres,
        map3d,
        candidate_points,
        tree,
        radius_step,
        anchors=(),
    )


def _insert_projected_sphere_with_anchors(
    point: np.ndarray,
    level: str,
    spheres: list[SphereNode],
    map3d: Map3D,
    candidate_points: np.ndarray,
    tree,
    radius_step: float,
    anchors: tuple[SphereNode, ...],
) -> int | None:
    if not anchors:
        covered = _nearest_covering_sphere(point, spheres, map3d, use_safe=False)
        if covered is not None:
            return covered
    k = min(24, len(candidate_points))
    distances, indices = tree.query(point.astype(np.float32), k=k)
    indices_array = np.atleast_1d(indices).astype(int)
    distances_array = np.atleast_1d(distances).astype(float)
    existing = {tuple(np.round(sphere.center, 6).tolist()) for sphere in spheres}
    best: tuple[float, np.ndarray, tuple[int, int, int], float] | None = None

    for idx, distance in zip(indices_array, distances_array):
        projected = candidate_points[int(idx)].astype(np.float32)
        if tuple(np.round(projected, 6).tolist()) in existing:
            continue
        voxel = tuple(world_to_voxel(projected, map3d.resolution, map3d.origin).tolist())
        esdf_value = float(map3d.esdf_grid[voxel])
        radius = quantize_radius(esdf_value, esdf_value, map3d.clearance_threshold, radius_step)
        if radius < map3d.clearance_threshold:
            continue
        candidate = SphereNode(
            id=-1,
            center=projected,
            radius=float(radius),
            level=level,  # type: ignore[arg-type]
            region_id=0,
        )
        overlap_margin = 0.0
        if anchors:
            overlap_margin = min(
                safe_radius(map3d, candidate) + safe_radius(map3d, anchor) - float(np.linalg.norm(projected - anchor.center))
                for anchor in anchors
            )
        score = 2.5 * overlap_margin + esdf_value - 0.1 * distance
        if best is None or score > best[0]:
            best = (score, projected, voxel, radius)

    if best is None:
        projected = nearest_point(point, tree, candidate_points)
        if tuple(np.round(projected, 6).tolist()) in existing:
            return None
        voxel = tuple(world_to_voxel(projected, map3d.resolution, map3d.origin).tolist())
        esdf_value = float(map3d.esdf_grid[voxel])
        radius = quantize_radius(esdf_value, esdf_value, map3d.clearance_threshold, radius_step)
        if radius < map3d.clearance_threshold:
            return None
    else:
        _, projected, voxel, radius = best

    region_id = int(map3d.metadata.get("component_labels", np.zeros_like(map3d.esdf_grid))[voxel]) if "component_labels" in map3d.metadata else 0
    spheres.append(
        SphereNode(
            id=len(spheres),
            center=projected.astype(np.float32),
            radius=float(radius),
            level=level,  # type: ignore[arg-type]
            region_id=region_id,
        )
    )
    return spheres[-1].id


def _densify_reference_graph(
    map3d: Map3D,
    topo_ref: TopoReference,
    spheres: list[SphereNode],
    candidate_points: np.ndarray,
    tree,
    radius_step: float,
    level: str,
) -> list[SphereNode]:
    enriched = list(spheres)
    step = max(map3d.resolution, 0.5 * map3d.clearance_threshold) if topo_ref.beta[1] > 1 else max(
        map3d.resolution,
        0.8 * map3d.clearance_threshold,
    )
    graph_nodes = map3d.metadata.get("graph_nodes", topo_ref.graph_nodes)
    graph_edges = map3d.metadata.get("graph_edges", topo_ref.graph_edges)
    for left, right in graph_edges:
        polyline = np.asarray([graph_nodes[left], graph_nodes[right]], dtype=np.float32)
        for point in sample_polyline(polyline, step=step):
            _insert_projected_sphere(point, level, enriched, map3d, candidate_points, tree, radius_step)
    return _reindex_spheres(enriched)


def _reference_graph(topo_ref: TopoReference) -> nx.Graph:
    graph = nx.Graph()
    for name, point in topo_ref.graph_nodes.items():
        graph.add_node(name, point=point)
    graph.add_edges_from(topo_ref.graph_edges)
    return graph


def _registered_reference_paths(topo_ref: TopoReference) -> list[tuple[tuple[int, ...], tuple[str, str], np.ndarray]]:
    graph = _reference_graph(topo_ref)
    target_signatures = {
        tuple(signature)
        for signature in topo_ref.signature_library.portal_path_sigs
    }
    if not target_signatures:
        return []
    weighted = nx.Graph()
    weighted.add_nodes_from(graph.nodes)
    for left, right in graph.edges():
        weighted.add_edge(
            left,
            right,
            weight=float(np.linalg.norm(topo_ref.graph_nodes[left] - topo_ref.graph_nodes[right])),
        )
    best_by_signature: dict[tuple[int, ...], tuple[float, tuple[str, str], np.ndarray]] = {}
    max_paths_per_pair = max(8, 8 * len(target_signatures))
    for start, goal in topo_ref.portal_pairs:
        if start not in graph or goal not in graph or not nx.has_path(graph, start, goal):
            continue
        iterator = islice(nx.shortest_simple_paths(weighted, start, goal, weight="weight"), max_paths_per_pair)
        for path in iterator:
            polyline = np.asarray([topo_ref.graph_nodes[name] for name in path], dtype=np.float32)
            signature = accumulate_signature(polyline, topo_ref.cut_surfaces.surfaces)
            if signature not in target_signatures:
                continue
            length = float(np.linalg.norm(polyline[1:] - polyline[:-1], axis=1).sum()) if len(polyline) >= 2 else 0.0
            current = best_by_signature.get(signature)
            if current is None or length < current[0]:
                best_by_signature[signature] = (length, (start, goal), polyline)
            if len(best_by_signature) == len(target_signatures):
                break
    return [
        (signature, portal_pair, polyline)
        for signature, (_, portal_pair, polyline) in sorted(best_by_signature.items(), key=lambda item: (item[0], item[1][0]))
    ]


def _collect_valid_registered_paths(
    registered_paths: list[RegisteredPathRealization],
) -> tuple[list[RegisteredPathRealization], set[tuple[int, int]], list[tuple[int, ...]]]:
    best_by_signature: dict[tuple[int, ...], RegisteredPathRealization] = {}
    for realization in registered_paths:
        if not realization.is_valid or not realization.sphere_chain:
            continue
        current = best_by_signature.get(realization.signature)
        if current is None or len(realization.sphere_chain) < len(current.sphere_chain):
            best_by_signature[realization.signature] = realization
    valid = [
        best_by_signature[signature]
        for signature in sorted(best_by_signature)
    ]
    protected_edges = {
        stable_edge(left_id, right_id)
        for realization in valid
        for left_id, right_id in zip(realization.sphere_chain[:-1], realization.sphere_chain[1:])
    }
    return valid, protected_edges, [realization.signature for realization in valid]


def _activate_registered_paths(
    topo_ref: TopoReference,
    registered_paths: list[RegisteredPathRealization],
    protected_edges: set[tuple[int, int]],
) -> None:
    portal_path_sigs = [realization.signature for realization in registered_paths]
    topo_ref.registered_paths = registered_paths
    topo_ref.protected_edges = protected_edges
    topo_ref.signature_library.portal_path_sigs = portal_path_sigs
    topo_ref.signature_library.all_sigs = set(topo_ref.signature_library.witness_sigs) | set(portal_path_sigs)


def _remap_witness_realizations(
    realizations: list[WitnessRealization],
    id_map: dict[int, int],
) -> list[WitnessRealization]:
    remapped: list[WitnessRealization] = []
    for realization in realizations:
        if not all(node_id in id_map for node_id in realization.sphere_chain):
            continue
        remapped.append(
            WitnessRealization(
                witness_id=realization.witness_id,
                sphere_chain=[id_map[node_id] for node_id in realization.sphere_chain],
                topo_signature=realization.topo_signature,
                is_nontrivial=realization.is_nontrivial,
            )
        )
    return remapped


def _remap_registered_realizations(
    realizations: list[RegisteredPathRealization],
    id_map: dict[int, int],
) -> list[RegisteredPathRealization]:
    remapped: list[RegisteredPathRealization] = []
    for realization in realizations:
        if not all(node_id in id_map for node_id in realization.sphere_chain):
            continue
        remapped.append(
            RegisteredPathRealization(
                signature=realization.signature,
                sphere_chain=[id_map[node_id] for node_id in realization.sphere_chain],
                portal_pair=realization.portal_pair,
                is_valid=realization.is_valid,
            )
        )
    return remapped


def _trim_to_initial_and_protected(
    initial_count: int,
    spheres: list[SphereNode],
    realizations: list[WitnessRealization],
    registered_paths: list[RegisteredPathRealization],
) -> tuple[list[SphereNode], list[WitnessRealization], list[RegisteredPathRealization]]:
    keep_ids = set(range(min(initial_count, len(spheres))))
    for realization in realizations:
        keep_ids.update(realization.sphere_chain)
    for realization in registered_paths:
        keep_ids.update(realization.sphere_chain)
    kept = [sphere for sphere in spheres if sphere.id in keep_ids]
    id_map = {sphere.id: idx for idx, sphere in enumerate(kept)}
    trimmed = _reindex_spheres(kept)
    return (
        trimmed,
        _remap_witness_realizations(realizations, id_map),
        _remap_registered_realizations(registered_paths, id_map),
    )


def _build_chain_from_polyline(
    polyline: np.ndarray,
    level: str,
    working: list[SphereNode],
    map3d: Map3D,
    candidate_points: np.ndarray,
    tree,
    radius_step: float,
    allow_insert: bool,
    step_scale: float,
) -> tuple[list[SphereNode], list[int]]:
    sampled = sample_polyline(polyline, step=max(0.5 * map3d.resolution, step_scale * map3d.clearance_threshold))
    chain: list[int] = []
    for point in sampled:
        sphere_id = _nearest_covering_sphere(point, working, map3d, use_safe=False)
        if sphere_id is None and allow_insert:
            _insert_projected_sphere(point, level, working, map3d, candidate_points, tree, radius_step)
            working = _reindex_spheres(working)
            sphere_id = _nearest_covering_sphere(point, working, map3d, use_safe=False)
        if sphere_id is None:
            return working, []
        if not chain or chain[-1] != sphere_id:
            chain.append(sphere_id)
    return working, chain


def _repair_open_chain(
    polyline: np.ndarray,
    level: str,
    working: list[SphereNode],
    map3d: Map3D,
    candidate_points: np.ndarray,
    tree,
    radius_step: float,
    allow_insert: bool,
) -> tuple[list[SphereNode], list[int], bool]:
    working, chain = _build_chain_from_polyline(
        polyline,
        level,
        working,
        map3d,
        candidate_points,
        tree,
        radius_step,
        allow_insert=allow_insert,
        step_scale=0.45,
    )
    if not chain:
        return working, chain, False

    for _ in range(20):
        lookup = {sphere.id: sphere for sphere in working}
        updated = False
        for left_id, right_id in zip(chain[:-1], chain[1:]):
            left = lookup[left_id]
            right = lookup[right_id]
            distance = float(np.linalg.norm(left.center - right.center))
            if distance < safe_radius(map3d, left) + safe_radius(map3d, right):
                continue
            if not allow_insert:
                return working, chain, False
            midpoint = 0.5 * (left.center + right.center)
            inserted = _insert_projected_sphere_with_anchors(
                midpoint,
                level,
                working,
                map3d,
                candidate_points,
                tree,
                radius_step,
                anchors=(left, right),
            )
            if inserted is None:
                segment = np.asarray([left.center, right.center], dtype=np.float32)
                for sample in sample_polyline(segment, step=max(0.5 * map3d.resolution, 0.3 * map3d.clearance_threshold)):
                    inserted = _insert_projected_sphere_with_anchors(
                        sample,
                        level,
                        working,
                        map3d,
                        candidate_points,
                        tree,
                        radius_step,
                        anchors=(left, right),
                    )
                    if inserted is not None:
                        break
            if inserted is None:
                return working, chain, False
            working = _reindex_spheres(working)
            working, chain = _build_chain_from_polyline(
                polyline,
                level,
                working,
                map3d,
                candidate_points,
                tree,
                radius_step,
                allow_insert=allow_insert,
                step_scale=0.35,
            )
            if not chain:
                return working, chain, False
            updated = True
            break
        if not updated:
            break

    lookup = {sphere.id: sphere for sphere in working}
    valid = all(
        float(np.linalg.norm(lookup[left_id].center - lookup[right_id].center))
        < safe_radius(map3d, lookup[left_id]) + safe_radius(map3d, lookup[right_id])
        for left_id, right_id in zip(chain[:-1], chain[1:])
    )
    return working, chain, valid


def _repair_cycle_chain(
    chain: list[int],
    level: str,
    working: list[SphereNode],
    map3d: Map3D,
    candidate_points: np.ndarray,
    tree,
    radius_step: float,
) -> tuple[list[SphereNode], list[int], bool]:
    if len(chain) < 2:
        return working, chain, False
    for _ in range(20):
        lookup = {sphere.id: sphere for sphere in working}
        updated = False
        repaired = [chain[0]]
        for left_id, right_id in zip(chain[:-1], chain[1:]):
            left = lookup[left_id]
            right = lookup[right_id]
            distance = float(np.linalg.norm(left.center - right.center))
            if distance < safe_radius(map3d, left) + safe_radius(map3d, right):
                repaired.append(right_id)
                continue
            midpoint = 0.5 * (left.center + right.center)
            inserted = _insert_projected_sphere_with_anchors(
                midpoint,
                level,
                working,
                map3d,
                candidate_points,
                tree,
                radius_step,
                anchors=(left, right),
            )
            if inserted is None:
                return working, chain, False
            working = _reindex_spheres(working)
            repaired.extend([inserted, right_id])
            updated = True
        chain = repaired
        if not updated:
            break

    lookup = {sphere.id: sphere for sphere in working}
    valid = all(
        float(np.linalg.norm(lookup[left_id].center - lookup[right_id].center))
        < safe_radius(map3d, lookup[left_id]) + safe_radius(map3d, lookup[right_id])
        for left_id, right_id in zip(chain[:-1], chain[1:])
    )
    return working, chain, valid


def _chain_has_safe_overlap(map3d: Map3D, working: list[SphereNode], chain: list[int]) -> bool:
    if len(chain) < 2:
        return False
    lookup = {sphere.id: sphere for sphere in working}
    return all(
        float(np.linalg.norm(lookup[left_id].center - lookup[right_id].center))
        < safe_radius(map3d, lookup[left_id]) + safe_radius(map3d, lookup[right_id])
        for left_id, right_id in zip(chain[:-1], chain[1:])
    )


def _normalize_signature_to_target(signature: tuple[int, ...], target_signature: tuple[int, ...]) -> tuple[int, ...]:
    if not signature or not target_signature or len(signature) != len(target_signature):
        return signature
    scale: int | None = None
    for value, target in zip(signature, target_signature):
        if target == 0:
            if value != 0:
                return signature
            continue
        if value % target != 0:
            return signature
        current = value // target
        if current == 0:
            return signature
        if scale is None:
            scale = current
        elif scale != current:
            return signature
    if scale is None or abs(scale) <= 1:
        return signature
    return tuple(int(value // scale) for value in signature)


def _find_matching_cycle(
    map3d: Map3D,
    topo_ref: TopoReference,
    working: list[SphereNode],
    nerve,
    context,
    target_signature: tuple[int, ...],
    seed_chain: list[int],
) -> tuple[list[int], tuple[int, ...], bool]:
    graph = nx.Graph()
    graph.add_nodes_from(sphere.id for sphere in working)
    graph.add_edges_from(nerve.simplices.get(1, []))
    candidate_nodes = set(seed_chain)
    for node_id in seed_chain:
        if node_id in graph:
            candidate_nodes.update(graph.neighbors(node_id))
    local_graph = graph.subgraph(candidate_nodes).copy() if candidate_nodes else graph
    for cycle_nodes in nx.cycle_basis(local_graph):
        chain = list(cycle_nodes) + [cycle_nodes[0]]
        signature = chain_signature(
            {sphere.id: sphere for sphere in working},
            chain,
            topo_ref.cut_surfaces.surfaces,
            resolution=map3d.resolution,
            safety_margin=map3d.safety_margin,
        )
        signature = _normalize_signature_to_target(signature, target_signature)
        if signature != target_signature:
            continue
        cycle_edges = [stable_edge(left_id, right_id) for left_id, right_id in zip(chain[:-1], chain[1:])]
        if cycle_is_nontrivial(cycle_edges, context):
            return chain, signature, True
    return [], tuple(), False


def _weighted_nerve_graph(working: list[SphereNode], nerve) -> nx.Graph:
    lookup = {sphere.id: sphere for sphere in working}
    graph = nx.Graph()
    graph.add_nodes_from(lookup)
    for left_id, right_id in nerve.simplices.get(1, []):
        graph.add_edge(
            left_id,
            right_id,
            weight=float(np.linalg.norm(lookup[left_id].center - lookup[right_id].center)),
        )
    return graph


def _path_polyline(
    start: np.ndarray,
    goal: np.ndarray,
    working: list[SphereNode],
    chain: list[int],
) -> np.ndarray:
    lookup = {sphere.id: sphere for sphere in working}
    points: list[np.ndarray] = [np.asarray(start, dtype=np.float32)]
    for node_id in chain:
        if node_id in lookup:
            points.append(lookup[node_id].center.astype(np.float32))
    points.append(np.asarray(goal, dtype=np.float32))
    deduped = [points[0]]
    for point in points[1:]:
        if float(np.linalg.norm(point - deduped[-1])) > 1e-6:
            deduped.append(point)
    return np.asarray(deduped, dtype=np.float32)


def _repair_default_audit_path(
    map3d: Map3D,
    topo_ref: TopoReference,
    working: list[SphereNode],
    candidate_points: np.ndarray,
    tree,
    radius_step: float,
) -> tuple[list[SphereNode], bool]:
    start = map3d.metadata.get("audit_start")
    goal = map3d.metadata.get("audit_goal")
    if start is None or goal is None:
        return working, False
    start_point = np.asarray(start, dtype=np.float32)
    goal_point = np.asarray(goal, dtype=np.float32)
    start_id = _nearest_covering_sphere(start_point, working, map3d, use_safe=False)
    goal_id = _nearest_covering_sphere(goal_point, working, map3d, use_safe=False)
    if start_id is None or goal_id is None:
        return working, False
    nerve, _ = construct_full_nerve(map3d, working)
    raw_graph = _weighted_nerve_graph(working, nerve)
    if start_id not in raw_graph or goal_id not in raw_graph:
        return working, False
    try:
        raw_path = nx.shortest_path(raw_graph, start_id, goal_id, weight="weight")
    except nx.NetworkXNoPath:
        return working, False
    polyline = _path_polyline(start_point, goal_point, working, raw_path)
    repaired_working, repaired_chain, valid = _repair_open_chain(
        polyline,
        "refine",
        working,
        map3d,
        candidate_points,
        tree,
        radius_step,
        allow_insert=True,
    )
    if not valid or not repaired_chain:
        return working, False
    repaired_working = _reindex_spheres(repaired_working)
    repaired_nerve, _ = construct_full_nerve(map3d, repaired_working)
    if repaired_nerve.betti != topo_ref.beta:
        return working, False
    return repaired_working, True


def _safe_overlap_graph(map3d: Map3D, working: list[SphereNode], nerve) -> nx.Graph:
    lookup = {sphere.id: sphere for sphere in working}
    graph = nx.Graph()
    graph.add_nodes_from(lookup)
    for left_id, right_id in nerve.simplices.get(1, []):
        left = lookup[left_id]
        right = lookup[right_id]
        distance = float(np.linalg.norm(left.center - right.center))
        if distance < safe_radius(map3d, left) + safe_radius(map3d, right):
            graph.add_edge(left_id, right_id, weight=distance)
    return graph


def _reroute_cycle_on_safe_graph(
    map3d: Map3D,
    topo_ref: TopoReference,
    working: list[SphereNode],
    nerve,
    context,
    chain: list[int],
    target_signature: tuple[int, ...],
) -> tuple[list[int], tuple[int, ...], bool]:
    if len(chain) < 2:
        return chain, tuple(), False
    safe_graph = _safe_overlap_graph(map3d, working, nerve)
    repaired = [chain[0]]
    for left_id, right_id in zip(chain[:-1], chain[1:]):
        if safe_graph.has_edge(left_id, right_id):
            repaired.append(right_id)
            continue
        try:
            detour = nx.shortest_path(safe_graph, left_id, right_id, weight="weight")
        except nx.NetworkXNoPath:
            return chain, tuple(), False
        repaired.extend(detour[1:])
    cleaned = [repaired[0]]
    for node_id in repaired[1:]:
        if node_id != cleaned[-1]:
            cleaned.append(node_id)
    signature = chain_signature(
        {sphere.id: sphere for sphere in working},
        cleaned,
        topo_ref.cut_surfaces.surfaces,
        resolution=map3d.resolution,
        safety_margin=map3d.safety_margin,
    )
    signature = _normalize_signature_to_target(signature, target_signature)
    cycle_edges = [stable_edge(left_id, right_id) for left_id, right_id in zip(cleaned[:-1], cleaned[1:])]
    is_nontrivial = _chain_has_safe_overlap(map3d, working, cleaned) and cycle_is_nontrivial(cycle_edges, context)
    if target_signature and signature != target_signature:
        return cleaned, signature, False
    return cleaned, signature, is_nontrivial


def _shrink_false_merges(map3d: Map3D, spheres: list[SphereNode], protected: set[int]) -> tuple[list[SphereNode], bool]:
    nerve, context = construct_full_nerve(map3d, spheres)
    labels = {sphere.id: _sphere_majority_label(map3d, context.safe_voxels[sphere.id]) for sphere in spheres}
    delta = map3d.resolution / 4.0
    changed = False
    kept = {sphere.id: sphere for sphere in spheres}
    for left_id, right_id in nerve.simplices.get(1, []):
        left_label = labels.get(left_id, 0)
        right_label = labels.get(right_id, 0)
        if left_label <= 0 or right_label <= 0 or left_label == right_label:
            continue
        left = kept[left_id]
        right = kept[right_id]
        distance = float(np.linalg.norm(left.center - right.center))
        target_id = left_id if left.radius <= right.radius else right_id
        if target_id in protected:
            target_id = right_id if target_id == left_id else left_id
        if target_id in protected:
            continue
        target = kept[target_id]
        other = kept[right_id] if target_id == left_id else kept[left_id]
        while target.radius - delta >= map3d.clearance_threshold and distance < target.radius + other.radius:
            target = SphereNode(
                id=target.id,
                center=target.center.copy(),
                radius=float(target.radius - delta),
                level=target.level,
                region_id=target.region_id,
            )
            kept[target.id] = target
            changed = True
        if distance < target.radius + other.radius:
            del kept[target_id]
            changed = True
    return _reindex_spheres(list(kept.values())), changed


def realize_witnesses(
    map3d: Map3D,
    topo_ref: TopoReference,
    spheres: list[SphereNode],
    allow_insert: bool = True,
) -> tuple[list[SphereNode], list[WitnessRealization]]:
    if not topo_ref.witness_cycles:
        return spheres, []
    candidate_sets = compute_candidate_sets(map3d)
    tree, candidate_points = build_kdtree(candidate_sets.centers)
    radius_step = candidate_sets.radius_step
    working = _reindex_spheres(list(spheres))
    realizations: list[WitnessRealization] = []

    for witness_id, witness_cycle in enumerate(topo_ref.witness_cycles):
        target_signature = topo_ref.signature_library.witness_sigs[witness_id] if witness_id < len(topo_ref.signature_library.witness_sigs) else tuple()
        sampled = sample_polyline(witness_cycle, step=max(map3d.resolution, 0.75 * map3d.clearance_threshold))
        chain: list[int] = []
        for point in sampled:
            sphere_id = _nearest_covering_sphere(point, working, map3d, use_safe=False)
            if sphere_id is None and allow_insert:
                _insert_projected_sphere(point, "repair", working, map3d, candidate_points, tree, radius_step)
                working = _reindex_spheres(working)
                sphere_id = _nearest_covering_sphere(point, working, map3d, use_safe=False)
            if sphere_id is None:
                chain = []
                break
            if not chain or chain[-1] != sphere_id:
                chain.append(sphere_id)

        if not chain:
            if not target_signature:
                realizations.append(WitnessRealization(witness_id, [], tuple(), False))
                continue
            nerve, context = construct_full_nerve(map3d, working)
            matched_chain, matched_signature, matched_ok = _find_matching_cycle(
                map3d,
                topo_ref,
                working,
                nerve,
                context,
                target_signature,
                [],
            )
            if not matched_ok:
                realizations.append(WitnessRealization(witness_id, [], tuple(), False))
                continue
            chain = matched_chain

        if chain[0] != chain[-1]:
            chain.append(chain[0])

        for _ in range(10):
            updated = False
            lookup = {sphere.id: sphere for sphere in working}
            for left_id, right_id in zip(chain[:-1], chain[1:]):
                left = lookup[left_id]
                right = lookup[right_id]
                distance = float(np.linalg.norm(left.center - right.center))
                if distance >= safe_radius(map3d, left) + safe_radius(map3d, right):
                    if not allow_insert:
                        break
                    midpoint = 0.5 * (left.center + right.center)
                    _insert_projected_sphere(midpoint, "refine", working, map3d, candidate_points, tree, radius_step)
                    working = _reindex_spheres(working)
                    sampled = sample_polyline(witness_cycle, step=max(map3d.resolution, 0.6 * map3d.clearance_threshold))
                    chain = []
                    for point in sampled:
                        sphere_id = _nearest_covering_sphere(point, working, map3d, use_safe=False)
                        if sphere_id is None:
                            chain = []
                            break
                        if not chain or chain[-1] != sphere_id:
                            chain.append(sphere_id)
                    if chain and chain[0] != chain[-1]:
                        chain.append(chain[0])
                    updated = True
                    break
            if not updated:
                break

        nerve, context = construct_full_nerve(map3d, working)
        cycle_edges = [stable_edge(left_id, right_id) for left_id, right_id in zip(chain[:-1], chain[1:])] if len(chain) >= 2 else []
        signature = chain_signature(
            {sphere.id: sphere for sphere in working},
            chain,
            topo_ref.cut_surfaces.surfaces,
            resolution=map3d.resolution,
            safety_margin=map3d.safety_margin,
        )
        if target_signature:
            signature = _normalize_signature_to_target(signature, target_signature)
        is_nontrivial = cycle_is_nontrivial(cycle_edges, context) if cycle_edges else False
        if target_signature:
            matched_chain, matched_signature, matched_ok = _find_matching_cycle(
                map3d,
                topo_ref,
                working,
                nerve,
                context,
                target_signature,
                chain,
            )
            if matched_ok:
                chain = matched_chain
                for _ in range(3):
                    working, repaired_chain, safe_ok = _repair_cycle_chain(
                        chain,
                        "refine",
                        working,
                        map3d,
                        candidate_points,
                        tree,
                        radius_step,
                    )
                    nerve, context = construct_full_nerve(map3d, working)
                    rematched_chain, rematched_signature, rematched_ok = _find_matching_cycle(
                        map3d,
                        topo_ref,
                        working,
                        nerve,
                        context,
                        target_signature,
                        repaired_chain,
                    )
                    if rematched_ok and _chain_has_safe_overlap(map3d, working, rematched_chain):
                        chain = rematched_chain
                        signature = rematched_signature
                        cycle_edges = [stable_edge(left_id, right_id) for left_id, right_id in zip(chain[:-1], chain[1:])]
                        is_nontrivial = True
                        break
                    chain = repaired_chain
                    signature = chain_signature(
                        {sphere.id: sphere for sphere in working},
                        chain,
                        topo_ref.cut_surfaces.surfaces,
                        resolution=map3d.resolution,
                        safety_margin=map3d.safety_margin,
                    )
                    if target_signature:
                        signature = _normalize_signature_to_target(signature, target_signature)
                    cycle_edges = [stable_edge(left_id, right_id) for left_id, right_id in zip(chain[:-1], chain[1:])]
                    is_nontrivial = safe_ok and signature == target_signature and cycle_is_nontrivial(cycle_edges, context)
                    if is_nontrivial:
                        break
        if target_signature and (not is_nontrivial or not _chain_has_safe_overlap(map3d, working, chain)):
            rerouted_chain, rerouted_signature, rerouted_ok = _reroute_cycle_on_safe_graph(
                map3d,
                topo_ref,
                working,
                nerve,
                context,
                chain,
                target_signature,
            )
            if rerouted_ok:
                chain = rerouted_chain
                signature = rerouted_signature
                cycle_edges = [stable_edge(left_id, right_id) for left_id, right_id in zip(chain[:-1], chain[1:])]
                is_nontrivial = True
        realizations.append(
            WitnessRealization(
                witness_id=witness_id,
                sphere_chain=chain,
                topo_signature=signature,
                is_nontrivial=is_nontrivial and (not target_signature or signature == target_signature),
            )
        )
    return _reindex_spheres(working), realizations


def realize_registered_paths(
    map3d: Map3D,
    topo_ref: TopoReference,
    spheres: list[SphereNode],
    allow_insert: bool = True,
) -> tuple[list[SphereNode], list[RegisteredPathRealization], set[tuple[int, int]]]:
    paths = _registered_reference_paths(topo_ref)
    if not paths:
        return spheres, [], set()

    candidate_sets = compute_candidate_sets(map3d)
    tree, candidate_points = build_kdtree(candidate_sets.centers)
    radius_step = candidate_sets.radius_step
    working = _reindex_spheres(list(spheres))
    realizations: list[RegisteredPathRealization] = []
    protected_edges: set[tuple[int, int]] = set()

    for signature, portal_pair, polyline in paths:
        working, chain, valid = _repair_open_chain(
            polyline,
            "portal",
            working,
            map3d,
            candidate_points,
            tree,
            radius_step,
            allow_insert=allow_insert,
        )
        realized_signature = chain_signature(
            {sphere.id: sphere for sphere in working},
            chain,
            topo_ref.cut_surfaces.surfaces,
            resolution=map3d.resolution,
            safety_margin=map3d.safety_margin,
            start=polyline[0],
            goal=polyline[-1],
        ) if chain else tuple()
        is_valid = valid and realized_signature == signature
        if is_valid:
            protected_edges.update(stable_edge(left_id, right_id) for left_id, right_id in zip(chain[:-1], chain[1:]))
        realizations.append(
            RegisteredPathRealization(
                signature=signature,
                sphere_chain=chain,
                portal_pair=portal_pair,
                is_valid=is_valid,
            )
        )
    return _reindex_spheres(working), realizations, protected_edges


def correct_cover(map3d: Map3D, topo_ref: TopoReference, spheres: list[SphereNode]) -> tuple[list[SphereNode], list[WitnessRealization]]:
    candidate_sets = compute_candidate_sets(map3d)
    tree, candidate_points = build_kdtree(candidate_sets.centers)
    radius_step = candidate_sets.radius_step
    working = _reindex_spheres(list(spheres))
    initial_count = len(working)
    official_large = map3d.metadata.get("scene_source") == "subt_tsv_official" and len(
        map3d.metadata.get("graph_edges", topo_ref.graph_edges)
    ) > 128
    seen: set[tuple[tuple[float, float, float, float], ...]] = set()
    realizations: list[WitnessRealization] = []
    registered_paths: list[RegisteredPathRealization] = []
    protected_edges: set[tuple[int, int]] = set()

    for _ in range(10):
        nerve, _ = construct_full_nerve(map3d, working)
        protected = {sphere_id for realization in realizations for sphere_id in realization.sphere_chain}
        if nerve.betti[0] < topo_ref.beta[0]:
            working, changed = _shrink_false_merges(map3d, working, protected)
            if changed:
                continue
        if nerve.betti[0] > topo_ref.beta[0]:
            working = _densify_reference_graph(map3d, topo_ref, working, candidate_points, tree, radius_step, "repair")

        if nerve.betti == topo_ref.beta:
            quick_working, quick_realizations = realize_witnesses(map3d, topo_ref, working, allow_insert=False)
            quick_working, quick_registered_paths_raw, quick_protected_edges = realize_registered_paths(
                map3d,
                topo_ref,
                quick_working,
                allow_insert=False,
            )
            if official_large and all(realization.is_nontrivial for realization in quick_realizations):
                quick_working, _ = _repair_default_audit_path(
                    map3d,
                    topo_ref,
                    quick_working,
                    candidate_points,
                    tree,
                    radius_step,
                )
                quick_working, quick_realizations = realize_witnesses(map3d, topo_ref, quick_working, allow_insert=False)
                quick_working, quick_registered_paths_raw, _ = realize_registered_paths(
                    map3d,
                    topo_ref,
                    quick_working,
                    allow_insert=False,
                )
            if official_large:
                quick_registered_paths, quick_protected_edges, _ = _collect_valid_registered_paths(quick_registered_paths_raw)
                quick_paths_ok = True
            else:
                quick_registered_paths = quick_registered_paths_raw
                quick_paths_ok = all(path.is_valid for path in quick_registered_paths_raw)
            quick_sig_matrix = np.asarray(
                [realization.topo_signature for realization in quick_realizations if realization.topo_signature],
                dtype=int,
            )
            quick_sig_rank = int(Matrix(quick_sig_matrix).rank()) if quick_sig_matrix.size else 0
            if (
                all(realization.is_nontrivial for realization in quick_realizations)
                and quick_sig_rank == topo_ref.beta[1]
                and quick_paths_ok
            ):
                topo_ref.realizations = quick_realizations
                _activate_registered_paths(topo_ref, quick_registered_paths, quick_protected_edges)
                return quick_working, quick_realizations

        working, realizations = realize_witnesses(map3d, topo_ref, working, allow_insert=True)
        working, registered_paths_raw, protected_edges = realize_registered_paths(
            map3d,
            topo_ref,
            working,
            allow_insert=not official_large,
        )
        if official_large:
            working, _ = _repair_default_audit_path(
                map3d,
                topo_ref,
                working,
                candidate_points,
                tree,
                radius_step,
            )
            working, realizations = realize_witnesses(map3d, topo_ref, working, allow_insert=False)
            working, registered_paths_raw, _ = realize_registered_paths(
                map3d,
                topo_ref,
                working,
                allow_insert=False,
            )
            registered_paths, protected_edges, _ = _collect_valid_registered_paths(registered_paths_raw)
        else:
            registered_paths = registered_paths_raw
            valid_registered_paths = [path for path in registered_paths if path.is_valid]
            if valid_registered_paths:
                registered_paths = valid_registered_paths
                protected_edges = {
                    stable_edge(left_id, right_id)
                    for path in registered_paths
                    for left_id, right_id in zip(path.sphere_chain[:-1], path.sphere_chain[1:])
                }
        # Registered-path repair may insert bridge spheres that let a witness remap to a safe chain
        # without re-densifying the cover. Reuse those spheres before considering further insertions.
        working, realizations = realize_witnesses(map3d, topo_ref, working, allow_insert=False)
        if not all(realization.is_nontrivial for realization in realizations):
            working, realizations = realize_witnesses(map3d, topo_ref, working, allow_insert=not official_large)
        if len(working) > initial_count and not official_large:
            trimmed_working, trimmed_realizations, trimmed_registered_paths = _trim_to_initial_and_protected(
                initial_count,
                working,
                realizations,
                registered_paths,
            )
            working = trimmed_working
            realizations = trimmed_realizations
            registered_paths = trimmed_registered_paths
            protected_edges = {
                stable_edge(left_id, right_id)
                for path in registered_paths
                for left_id, right_id in zip(path.sphere_chain[:-1], path.sphere_chain[1:])
            }
        nerve, _ = construct_full_nerve(map3d, working)
        sig_matrix = np.asarray([realization.topo_signature for realization in realizations if realization.topo_signature], dtype=int)
        sig_rank = int(Matrix(sig_matrix).rank()) if sig_matrix.size else 0
        paths_ok = True if official_large else all(path.is_valid for path in registered_paths)

        if nerve.betti == topo_ref.beta and all(realization.is_nontrivial for realization in realizations) and sig_rank == topo_ref.beta[1] and paths_ok:
            topo_ref.realizations = realizations
            _activate_registered_paths(topo_ref, registered_paths, protected_edges)
            return working, realizations

        if not official_large:
            working = _densify_reference_graph(map3d, topo_ref, working, candidate_points, tree, radius_step, "refine")
        encoded = tuple(
            sorted(
                (
                    float(sphere.center[0]),
                    float(sphere.center[1]),
                    float(sphere.center[2]),
                    float(sphere.radius),
                )
                for sphere in working
            )
        )
        if encoded in seen:
            break
        seen.add(encoded)

    topo_ref.realizations = realizations
    _activate_registered_paths(topo_ref, registered_paths, protected_edges)
    return working, realizations
