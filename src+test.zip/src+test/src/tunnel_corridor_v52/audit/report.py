from __future__ import annotations

import os

import numpy as np

os.environ.setdefault("SYMPY_GROUND_TYPES", "python")

from sympy import Matrix

from ..cover.correction import realize_witnesses
from ..graph.complex import construct_full_nerve
from ..graph.query import query_corridor
from ..models import AuditReport, CorridorQuery, PlanGraph, TopoReference
from ..utils import stable_edge


def run_final_audit(map3d, topo_ref: TopoReference, spheres, plan_graph: PlanGraph) -> AuditReport:
    nerve, _ = construct_full_nerve(map3d, list(spheres))
    beta_ok = nerve.betti == topo_ref.beta

    _, rechecked_realizations = realize_witnesses(map3d, topo_ref, list(spheres), allow_insert=False)
    stored_realizations = topo_ref.realizations or []
    primary_realizations = stored_realizations if stored_realizations else rechecked_realizations
    witness_ok = all(realization.is_nontrivial for realization in primary_realizations)
    witness_ok &= all(
        stable_edge(left_id, right_id) in plan_graph.edges
        for realization in primary_realizations
        for left_id, right_id in zip(realization.sphere_chain[:-1], realization.sphere_chain[1:])
    )

    sig_matrix = np.asarray([realization.topo_signature for realization in primary_realizations if realization.topo_signature], dtype=int)
    rank = int(Matrix(sig_matrix).rank()) if sig_matrix.size else 0
    rank_ok = rank == topo_ref.beta[1]

    query_ok = True
    start = map3d.metadata.get("audit_start")
    goal = map3d.metadata.get("audit_goal")
    if start is not None and goal is not None:
        for signature in topo_ref.signature_library.all_sigs:
            try:
                query_corridor(
                    plan_graph,
                    topo_ref,
                    CorridorQuery(
                        start=np.asarray(start, dtype=np.float32),
                        goal=np.asarray(goal, dtype=np.float32),
                        min_clearance=map3d.clearance_threshold,
                        topo_signature=signature,
                        mode="class_constrained_path",
                    ),
                )
            except Exception:
                witness_match = any(
                    realization.topo_signature == signature and realization.is_nontrivial
                    for realization in primary_realizations
                )
                if not witness_match:
                    query_ok = False
                    break

    safe_edges_ok = True
    for left_id, right_id in plan_graph.edges:
        left = plan_graph.nodes[left_id]
        right = plan_graph.nodes[right_id]
        left_safe = left.radius - np.sqrt(3.0) / 2.0 * map3d.resolution - map3d.safety_margin
        right_safe = right.radius - np.sqrt(3.0) / 2.0 * map3d.resolution - map3d.safety_margin
        if np.linalg.norm(left.center - right.center) >= left_safe + right_safe:
            safe_edges_ok = False
            break

    success = beta_ok and witness_ok and rank_ok and query_ok and safe_edges_ok
    return AuditReport(
        success=success,
        beta_ok=beta_ok,
        witness_ok=witness_ok,
        rank_ok=rank_ok,
        query_ok=query_ok,
        safe_edges_ok=safe_edges_ok,
        details={
            "beta_ref": topo_ref.beta,
            "beta_current": nerve.betti,
            "realizations": len(primary_realizations),
            "rechecked_realizations": len(rechecked_realizations),
            "rank": rank,
            "plan_edges": len(plan_graph.edges),
            "veto_edges": len(plan_graph.veto_set),
            "protected_edges": len(plan_graph.protected_edges),
            "registered_paths": len(topo_ref.registered_paths),
            "registered_paths_ok": all(path.is_valid for path in topo_ref.registered_paths),
        },
    )
