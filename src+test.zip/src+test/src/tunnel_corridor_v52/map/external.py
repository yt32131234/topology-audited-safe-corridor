from __future__ import annotations

from pathlib import Path

import networkx as nx
import numpy as np
from scipy import ndimage as ndi
from skimage.measure import label

from ..models import Map3D
from ..topology.reference import _compressed_skeleton_graph, _metadata_graph


def _farthest_pair(graph: nx.Graph) -> tuple[str, str] | None:
    if graph.number_of_nodes() < 2:
        return None
    start = next(iter(graph.nodes))
    first = max(nx.single_source_dijkstra_path_length(graph, start).items(), key=lambda item: item[1])[0]
    lengths = nx.single_source_dijkstra_path_length(graph, first)
    second = max(lengths.items(), key=lambda item: item[1])[0]
    if first == second:
        return None
    return str(first), str(second)


def _infer_metadata(map3d: Map3D) -> dict[str, object]:
    safe_mask = map3d.esdf_grid >= map3d.clearance_threshold
    provided_graph, graph_nodes, graph_edges = _metadata_graph(map3d)
    if provided_graph.number_of_nodes() == 0:
        provided_graph, graph_nodes, graph_edges = _compressed_skeleton_graph(map3d, safe_mask)
    if provided_graph.number_of_nodes() >= 2:
        weighted = nx.Graph()
        for left, right in graph_edges:
            distance = float(np.linalg.norm(graph_nodes[left] - graph_nodes[right]))
            weighted.add_edge(left, right, weight=distance)
        portal_pair = _farthest_pair(weighted)
    else:
        portal_pair = None
    if portal_pair is None:
        coords = np.argwhere(safe_mask)
        if len(coords) >= 2:
            start_point = coords[0].astype(np.float32) * map3d.resolution + map3d.origin
            goal_point = coords[-1].astype(np.float32) * map3d.resolution + map3d.origin
        elif len(coords) == 1:
            start_point = coords[0].astype(np.float32) * map3d.resolution + map3d.origin
            goal_point = start_point.copy()
        else:
            start_point = map3d.origin.copy()
            goal_point = map3d.origin.copy()
        return {
            "graph_nodes": {},
            "graph_edges": [],
            "portal_pairs": [],
            "audit_start": start_point.astype(np.float32),
            "audit_goal": goal_point.astype(np.float32),
            "component_labels": label(safe_mask, connectivity=safe_mask.ndim),
        }

    start_name, goal_name = portal_pair
    return {
        "graph_nodes": graph_nodes,
        "graph_edges": graph_edges,
        "portal_pairs": [portal_pair],
        "audit_start": graph_nodes[start_name].astype(np.float32),
        "audit_goal": graph_nodes[goal_name].astype(np.float32),
        "component_labels": label(safe_mask, connectivity=safe_mask.ndim),
    }


def load_map3d_npz(
    path: str | Path,
    clearance: float | None = None,
    safety_margin: float | None = None,
) -> Map3D:
    with np.load(Path(path), allow_pickle=True) as payload:
        if "occupancy_grid" not in payload and "esdf_grid" not in payload:
            raise ValueError("External map npz must contain 'occupancy_grid' or 'esdf_grid'.")
        occupancy = payload["occupancy_grid"].astype(bool) if "occupancy_grid" in payload else None
        resolution = float(payload["resolution"]) if "resolution" in payload else 1.0
        origin = payload["origin"].astype(np.float32) if "origin" in payload else np.zeros(3, dtype=np.float32)
        inferred_clearance = float(payload["clearance_threshold"]) if "clearance_threshold" in payload else 2.0
        clearance_value = inferred_clearance if clearance is None else float(clearance)
        margin_value = (0.1 * resolution) if safety_margin is None else float(safety_margin)
        if "esdf_grid" in payload:
            esdf = payload["esdf_grid"].astype(np.float32)
            free_mask = esdf >= clearance_value
            if occupancy is None:
                occupancy = ~free_mask
        else:
            free_mask = ~occupancy
            esdf = ndi.distance_transform_edt(free_mask, sampling=resolution).astype(np.float32)
        metadata = {}
        if "metadata" in payload:
            raw = payload["metadata"].item()
            if isinstance(raw, dict):
                metadata.update(raw)
        map3d = Map3D(
            esdf_grid=esdf,
            resolution=resolution,
            origin=origin,
            clearance_threshold=clearance_value,
            safety_margin=margin_value,
            occupancy_grid=occupancy.astype(bool) if occupancy is not None else None,
            free_mask=free_mask.astype(bool),
            metadata=metadata,
        )
    inferred = _infer_metadata(map3d)
    for key, value in inferred.items():
        current = map3d.metadata.get(key)
        if key in {"graph_nodes", "graph_edges", "portal_pairs"}:
            if not current:
                map3d.metadata[key] = value
        else:
            map3d.metadata.setdefault(key, value)
    map3d.metadata.setdefault("scene_name", Path(path).stem)
    map3d.metadata.setdefault("scene_source", "external_npz")
    return map3d


def save_map3d_npz(map3d: Map3D, path: str | Path) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        target,
        esdf_grid=map3d.esdf_grid.astype(np.float32),
        occupancy_grid=(map3d.occupancy_grid.astype(bool) if map3d.occupancy_grid is not None else (~map3d.free_mask).astype(bool)),
        resolution=np.asarray(map3d.resolution, dtype=np.float32),
        origin=map3d.origin.astype(np.float32),
        clearance_threshold=np.asarray(map3d.clearance_threshold, dtype=np.float32),
        metadata=np.asarray(map3d.metadata, dtype=object),
    )
    return target
