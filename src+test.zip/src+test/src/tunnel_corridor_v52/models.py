from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

import numpy as np


@dataclass
class Map3D:
    esdf_grid: np.ndarray
    resolution: float
    origin: np.ndarray
    clearance_threshold: float
    safety_margin: float
    occupancy_grid: np.ndarray | None = None
    free_mask: np.ndarray | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class CandidateSets:
    centers: np.ndarray
    radius_step: float


@dataclass
class CutSurfaceBasis:
    surfaces: list[np.ndarray]
    witness_cycles: list[np.ndarray]
    intersection_matrix: np.ndarray


@dataclass
class SphereNode:
    id: int
    center: np.ndarray
    radius: float
    level: Literal["coarse", "repair", "refine", "portal"]
    region_id: int


@dataclass
class NerveGeo:
    simplices: dict[int, list[tuple[int, ...]]]
    betti: tuple[int, int]
    h1_basis: list[list[tuple[int, int]]]


@dataclass
class RegisteredSignatureLibrary:
    witness_sigs: list[tuple[int, ...]]
    portal_path_sigs: list[tuple[int, ...]]
    all_sigs: set[tuple[int, ...]]


@dataclass
class PlanGraph:
    nodes: dict[int, SphereNode]
    edges: set[tuple[int, int]]
    veto_set: set[tuple[int, int]]
    band_constraints: dict[int, set[int]]
    witness_chain_edges: set[tuple[int, int]]
    protected_edges: set[tuple[int, int]] = field(default_factory=set)
    edge_signatures: dict[tuple[int, int], tuple[int, ...]] = field(default_factory=dict)
    resolution: float = 1.0
    safety_margin: float = 0.0
    clearance_threshold: float = 0.0
    origin: np.ndarray | None = None
    esdf_grid: np.ndarray | None = None


@dataclass
class WitnessRealization:
    witness_id: int
    sphere_chain: list[int]
    topo_signature: tuple[int, ...]
    is_nontrivial: bool


@dataclass
class RegisteredPathRealization:
    signature: tuple[int, ...]
    sphere_chain: list[int]
    portal_pair: tuple[str, str]
    is_valid: bool


@dataclass
class TopoReference:
    beta: tuple[int, int]
    witness_cycles: list[np.ndarray]
    cut_surfaces: CutSurfaceBasis
    signature_library: RegisteredSignatureLibrary
    realizations: list[WitnessRealization] | None
    registered_paths: list[RegisteredPathRealization] = field(default_factory=list)
    protected_edges: set[tuple[int, int]] = field(default_factory=set)
    graph_nodes: dict[str, np.ndarray] = field(default_factory=dict)
    graph_edges: list[tuple[str, str]] = field(default_factory=list)
    portal_pairs: list[tuple[str, str]] = field(default_factory=list)
    portal_points: dict[str, np.ndarray] = field(default_factory=dict)


@dataclass
class SafetyCertificate:
    uniform_clearance_guarantee: float
    path_bottleneck_clearance: float
    topo_signature: tuple[int, ...]
    bottleneck_spheres: list[int]
    discretization_error: float


@dataclass
class PathQualityMetrics:
    lift_length: float
    detour_ratio: float
    min_clearance: float
    mean_clearance: float
    p05_clearance: float
    max_turn_deg: float
    mean_turn_deg: float
    curvature_proxy: float
    smoothness_proxy: float
    energy_proxy: float
    safe_overlap_rate: float
    query_latency_ms: float | None = None
    certificate_signature: tuple[int, ...] = field(default_factory=tuple)


@dataclass
class CorridorQuery:
    start: np.ndarray
    goal: np.ndarray
    min_clearance: float
    topo_signature: tuple[int, ...] | None = None
    mode: Literal["best_safe_path", "class_constrained_path"] = "best_safe_path"


@dataclass
class CorridorResult:
    sphere_path: list[int]
    corridor_spheres: list[tuple[np.ndarray, float]]
    certificate: SafetyCertificate
    path_length: float
    lift_polyline: np.ndarray | None = None
    quality_metrics: PathQualityMetrics | None = None


@dataclass
class AuditReport:
    success: bool
    beta_ok: bool
    witness_ok: bool
    rank_ok: bool
    query_ok: bool
    safe_edges_ok: bool
    details: dict[str, Any] = field(default_factory=dict)
