from __future__ import annotations

from collections.abc import Iterable

import networkx as nx
import numpy as np
from scipy import ndimage as ndi
from scipy.spatial import cKDTree

from ..models import CandidateSets, Map3D, SphereNode, TopoReference
from ..utils import build_kdtree, nearest_point, quantize_radius, sample_polyline, voxel_to_world, world_to_voxel


def compute_candidate_sets(map3d: Map3D) -> CandidateSets:
    safe_mask = map3d.esdf_grid >= map3d.clearance_threshold
    safe_indices = np.argwhere(safe_mask)
    centers = voxel_to_world(safe_indices, map3d.resolution, map3d.origin)
    return CandidateSets(centers=centers.astype(np.float32), radius_step=map3d.resolution / 4.0)


def _selected_graph_edges(map3d: Map3D, topo_ref: TopoReference) -> list[tuple[str, str]]:
    graph_nodes = map3d.metadata.get("graph_nodes", topo_ref.graph_nodes)
    graph_edges = list(map3d.metadata.get("graph_edges", topo_ref.graph_edges))
    if map3d.metadata.get("scene_source") != "subt_tsv_official" or len(graph_edges) <= 128:
        return graph_edges
    graph = nx.Graph()
    for name, point in graph_nodes.items():
        graph.add_node(name, point=np.asarray(point, dtype=np.float32))
    for left, right in graph_edges:
        graph.add_edge(left, right, weight=float(np.linalg.norm(np.asarray(graph_nodes[left]) - np.asarray(graph_nodes[right]))))
    selected = {tuple(sorted(edge)) for edge in nx.minimum_spanning_edges(graph, data=False, weight="weight")}
    selected.update(tuple(edge) for edge in map3d.metadata.get("selected_cycle_edges", []))
    if not selected:
        return graph_edges
    return [edge for edge in graph_edges if tuple(sorted(edge)) in selected]


def _reference_samples(
    map3d: Map3D,
    topo_ref: TopoReference,
    step: float,
    official_large: bool = False,
) -> list[tuple[np.ndarray, str, bool]]:
    samples: list[tuple[np.ndarray, str, bool]] = []
    graph_nodes = map3d.metadata.get("graph_nodes", topo_ref.graph_nodes)
    graph_edges = _selected_graph_edges(map3d, topo_ref)
    portal_names = {name for pair in map3d.metadata.get("portal_pairs", topo_ref.portal_pairs) for name in pair}
    for left, right in graph_edges:
        polyline = np.asarray([graph_nodes[left], graph_nodes[right]], dtype=np.float32)
        for point in sample_polyline(polyline, step=step):
            if official_large:
                # Forced portal-edge samples make official tunnel graphs explode in sphere count.
                # Keep the edge samples regular and preserve the actual portal nodes below.
                level = "repair"
                force = False
            else:
                level = "portal" if left in portal_names or right in portal_names else "repair"
                force = level == "portal" and topo_ref.beta[1] > 1
            samples.append((point, level, force))
    if not official_large:
        witness_step = max(step * 0.75, 1.0)
        witness_force = topo_ref.beta[1] > 1
        for cycle in topo_ref.witness_cycles:
            for point in sample_polyline(cycle, step=witness_step):
                samples.append((point, "repair", witness_force))
    for name, point in topo_ref.portal_points.items():
        samples.append((point, "portal", True))
    return samples


def _nms_keep(center: np.ndarray, radius: float, chosen: list[SphereNode], tau: float) -> bool:
    for sphere in chosen:
        distance = float(np.linalg.norm(center - sphere.center))
        if distance < tau * min(radius, sphere.radius):
            return False
    return True


def _safe_label_at(point: np.ndarray, map3d: Map3D) -> int:
    labels = map3d.metadata.get("component_labels")
    if labels is None:
        return 0
    index = world_to_voxel(point, map3d.resolution, map3d.origin)
    index = np.clip(index, [0, 0, 0], np.asarray(labels.shape) - 1)
    return int(labels[tuple(index)])


def build_initial_cover(map3d: Map3D, topo_ref: TopoReference) -> list[SphereNode]:
    candidate_sets = compute_candidate_sets(map3d)
    safe_mask = map3d.esdf_grid >= map3d.clearance_threshold
    tree, candidate_points = build_kdtree(candidate_sets.centers)
    radius_step = candidate_sets.radius_step
    official_large = map3d.metadata.get("scene_source") == "subt_tsv_official" and len(
        map3d.metadata.get("graph_edges", topo_ref.graph_edges)
    ) > 128
    nms_tau = 0.82 if official_large else 0.7
    maxima_limit = 16 if official_large else 40

    maxima = ndi.maximum_filter(map3d.esdf_grid, size=3) == map3d.esdf_grid
    maxima &= safe_mask
    maxima_indices = np.argwhere(maxima)
    maxima_scores = [float(map3d.esdf_grid[tuple(index)]) for index in maxima_indices]
    sorted_indices = [idx for _, idx in sorted(zip(maxima_scores, maxima_indices), key=lambda item: item[0], reverse=True)]

    spheres: list[SphereNode] = []
    used_voxels: set[tuple[int, int, int]] = set()

    def maybe_add(point: np.ndarray, level: str, force: bool = False) -> None:
        projected = nearest_point(point, tree, candidate_points)
        voxel = tuple(world_to_voxel(projected, map3d.resolution, map3d.origin).tolist())
        if voxel in used_voxels:
            return
        esdf_value = float(map3d.esdf_grid[voxel])
        radius = quantize_radius(esdf_value, esdf_value, map3d.clearance_threshold, radius_step)
        if radius < map3d.clearance_threshold:
            return
        if not force and not _nms_keep(projected, radius, spheres, tau=nms_tau):
            return
        used_voxels.add(voxel)
        spheres.append(
            SphereNode(
                id=len(spheres),
                center=projected.astype(np.float32),
                radius=float(radius),
                level=level,  # type: ignore[arg-type]
                region_id=_safe_label_at(projected, map3d),
            )
        )

    for index in sorted_indices[:maxima_limit]:
        point = voxel_to_world(index[None, :], map3d.resolution, map3d.origin)[0]
        maybe_add(point, "coarse")

    dense_topology = topo_ref.beta[1] > 1
    if dense_topology:
        step = (
            max(7.0 * map3d.resolution, 3.5 * map3d.clearance_threshold)
            if official_large
            else max(0.5 * map3d.resolution, 0.5 * map3d.clearance_threshold)
        )
    else:
        step = max(map3d.resolution, 0.75 * map3d.clearance_threshold)
    for point, level, force in _reference_samples(map3d, topo_ref, step=step, official_large=official_large):
        maybe_add(point, level, force=force)

    return spheres
