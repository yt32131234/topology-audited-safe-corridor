from __future__ import annotations

import numpy as np

from tunnel_corridor_v52.audit.report import run_final_audit
from tunnel_corridor_v52.cover.correction import correct_cover
from tunnel_corridor_v52.cover.initial import build_initial_cover
from tunnel_corridor_v52.graph.complex import construct_full_nerve
from tunnel_corridor_v52.graph.query import build_plan_graph, query_corridor
from tunnel_corridor_v52.map.sim import generate_scene
from tunnel_corridor_v52.models import CorridorQuery
from tunnel_corridor_v52.pipeline import run_scene, summarize_run
from tunnel_corridor_v52.topology.reference import build_topo_reference


def _run_scene(scene_name: str):
    map3d = generate_scene(scene_name, grid_shape=(48, 48, 48), resolution=1.0, clearance=2.0)
    topo_ref = build_topo_reference(map3d)
    coarse = build_initial_cover(map3d, topo_ref)
    corrected, realizations = correct_cover(map3d, topo_ref, coarse)
    plan_graph = build_plan_graph(map3d, topo_ref, corrected, realizations)
    audit = run_final_audit(map3d, topo_ref, corrected, plan_graph)
    return map3d, topo_ref, coarse, corrected, realizations, plan_graph, audit


def test_single_tunnel_pipeline_passes_audit():
    map3d, topo_ref, _, corrected, _, plan_graph, audit = _run_scene("single_tunnel")
    assert topo_ref.beta == (1, 0)
    assert corrected
    assert plan_graph.edges
    assert audit.success
    result = query_corridor(
        plan_graph,
        topo_ref,
        CorridorQuery(
            start=np.asarray(map3d.metadata["audit_start"], dtype=np.float32),
            goal=np.asarray(map3d.metadata["audit_goal"], dtype=np.float32),
            min_clearance=map3d.clearance_threshold,
        ),
    )
    assert result.path_length > 0.0


def test_double_tunnel_supports_signature_constrained_query():
    map3d, topo_ref, _, _, _, plan_graph, audit = _run_scene("double_tunnel")
    assert topo_ref.beta[1] == 1
    assert audit.success
    non_zero = [sig for sig in topo_ref.signature_library.portal_path_sigs if any(sig)]
    assert non_zero
    result = query_corridor(
        plan_graph,
        topo_ref,
        CorridorQuery(
            start=np.asarray(map3d.metadata["audit_start"], dtype=np.float32),
            goal=np.asarray(map3d.metadata["audit_goal"], dtype=np.float32),
            min_clearance=map3d.clearance_threshold,
            topo_signature=non_zero[0],
            mode="class_constrained_path",
        ),
    )
    assert result.certificate.topo_signature == non_zero[0]
    assert result.quality_metrics is not None
    assert result.quality_metrics.min_clearance > 0.0


def test_false_merge_trap_separates_nerve_and_plan_graph():
    map3d, topo_ref, coarse, corrected, _, plan_graph, audit = _run_scene("false_merge_trap")
    coarse_nerve, _ = construct_full_nerve(map3d, coarse)
    corrected_nerve, _ = construct_full_nerve(map3d, corrected)
    assert coarse_nerve.betti[0] <= topo_ref.beta[0]
    assert corrected_nerve.betti[0] == topo_ref.beta[0]
    assert len(plan_graph.veto_set) > 0 or len(corrected_nerve.simplices[1]) > len(plan_graph.edges)
    assert audit.success


def test_double_loop_summary_contains_quality_metrics():
    run = run_scene("double_loop")
    summary = summarize_run(run)
    assert summary["audit"]["success"] is True
    assert summary["corridor"]["quality_metrics"]["safe_overlap_rate"] == 1.0
    assert summary["corridor"]["quality_metrics"]["detour_ratio"] >= 1.0
