from __future__ import annotations

from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Any

import numpy as np

from .audit.report import run_final_audit
from .cover.correction import correct_cover
from .cover.initial import build_initial_cover
from .graph.query import build_plan_graph, query_corridor
from .map import generate_scene, load_map3d_npz
from .models import CorridorQuery, Map3D
from .topology.reference import build_topo_reference


def to_jsonable(value: Any) -> Any:
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if is_dataclass(value):
        return {key: to_jsonable(val) for key, val in asdict(value).items()}
    if isinstance(value, dict):
        return {str(key): to_jsonable(val) for key, val in value.items()}
    if isinstance(value, set):
        return [to_jsonable(item) for item in sorted(value)]
    if isinstance(value, (list, tuple)):
        return [to_jsonable(item) for item in value]
    return value


def default_query(map3d: Map3D) -> CorridorQuery:
    start = np.asarray(map3d.metadata["audit_start"], dtype=np.float32)
    goal = np.asarray(map3d.metadata["audit_goal"], dtype=np.float32)
    return CorridorQuery(start=start, goal=goal, min_clearance=map3d.clearance_threshold)


def run_pipeline(map3d: Map3D, query: CorridorQuery | None = None) -> dict[str, Any]:
    topo_ref = build_topo_reference(map3d)
    initial_cover = build_initial_cover(map3d, topo_ref)
    spheres, realizations = correct_cover(map3d, topo_ref, initial_cover)
    plan_graph = build_plan_graph(map3d, topo_ref, spheres, realizations)
    audit = run_final_audit(map3d, topo_ref, spheres, plan_graph)
    corridor_query = query or default_query(map3d)
    result = query_corridor(plan_graph, topo_ref, corridor_query)
    return {
        "map3d": map3d,
        "topo_ref": topo_ref,
        "initial_cover": initial_cover,
        "spheres": spheres,
        "realizations": realizations,
        "plan_graph": plan_graph,
        "audit": audit,
        "query": corridor_query,
        "corridor": result,
    }


def summarize_run(run: dict[str, Any]) -> dict[str, Any]:
    map3d = run["map3d"]
    topo_ref = run["topo_ref"]
    plan_graph = run["plan_graph"]
    audit = run["audit"]
    corridor = run["corridor"]
    return {
        "scene": map3d.metadata.get("scene_name", "unnamed_map"),
        "scene_source": map3d.metadata.get("scene_source", "synthetic"),
        "beta_ref": topo_ref.beta,
        "sphere_count": len(run["spheres"]),
        "realizations": len(run["realizations"]),
        "plan_edges": len(plan_graph.edges),
        "veto_edges": len(plan_graph.veto_set),
        "protected_edges": len(plan_graph.protected_edges),
        "audit": to_jsonable(audit),
        "corridor": to_jsonable(corridor),
    }


def run_scene(
    scene_name: str,
    grid_shape: tuple[int, int, int] = (48, 48, 48),
    resolution: float = 1.0,
    clearance: float = 2.0,
    query: CorridorQuery | None = None,
) -> dict[str, Any]:
    map3d = generate_scene(scene_name, grid_shape=grid_shape, resolution=resolution, clearance=clearance)
    return run_pipeline(map3d, query=query)


def run_pipeline_from_npz(
    npz_path: str | Path,
    clearance: float | None = None,
    query: CorridorQuery | None = None,
) -> dict[str, Any]:
    map3d = load_map3d_npz(npz_path, clearance=clearance)
    return run_pipeline(map3d, query=query)
