from __future__ import annotations

import math
import os
from dataclasses import dataclass

import networkx as nx
import numpy as np

from ..models import Map3D, NerveGeo, SphereNode
from ..utils import SQRT3_OVER_2, cycle_edge_vector, gf2_contains_column_space, gf2_rank, stable_edge, world_to_voxel


@dataclass
class NerveContext:
    raw_voxels: dict[int, set[int]]
    safe_voxels: dict[int, set[int]]
    edge_index: dict[tuple[int, int], int]
    boundary1: np.ndarray
    boundary2: np.ndarray
    triangles: list[tuple[int, int, int]]


def safe_radius(map3d: Map3D, sphere: SphereNode) -> float:
    return max(
        0.25 * map3d.clearance_threshold,
        sphere.radius - SQRT3_OVER_2 * map3d.resolution - map3d.safety_margin,
    )


def _sphere_voxels(map3d: Map3D, sphere: SphereNode, radius: float) -> set[int]:
    index = world_to_voxel(sphere.center, map3d.resolution, map3d.origin)
    radius_vox = int(math.ceil(radius / map3d.resolution))
    mins = np.maximum(0, index - radius_vox)
    maxs = np.minimum(np.asarray(map3d.esdf_grid.shape) - 1, index + radius_vox)
    xs, ys, zs = np.meshgrid(
        np.arange(mins[0], maxs[0] + 1),
        np.arange(mins[1], maxs[1] + 1),
        np.arange(mins[2], maxs[2] + 1),
        indexing="ij",
    )
    coords = np.stack([xs, ys, zs], axis=-1).astype(np.float32)
    world = map3d.origin + coords * map3d.resolution
    mask = np.linalg.norm(world - sphere.center.astype(np.float32), axis=-1) <= radius
    chosen = coords[mask].astype(int)
    if len(chosen) == 0:
        return set()
    flat = np.ravel_multi_index(chosen.T, map3d.esdf_grid.shape)
    return set(int(item) for item in flat)


def _boundary1(n_vertices: int, edges: list[tuple[int, int]]) -> np.ndarray:
    matrix = np.zeros((n_vertices, len(edges)), dtype=np.uint8)
    for col, (left, right) in enumerate(edges):
        matrix[left, col] = 1
        matrix[right, col] = 1
    return matrix


def _boundary2(edges: list[tuple[int, int]], triangles: list[tuple[int, int, int]]) -> tuple[np.ndarray, dict[tuple[int, int], int]]:
    edge_index = {edge: idx for idx, edge in enumerate(edges)}
    matrix = np.zeros((len(edges), len(triangles)), dtype=np.uint8)
    for col, tri in enumerate(triangles):
        tri_edges = [stable_edge(tri[0], tri[1]), stable_edge(tri[0], tri[2]), stable_edge(tri[1], tri[2])]
        for edge in tri_edges:
            matrix[edge_index[edge], col] ^= 1
    return matrix, edge_index


def _candidate_edge_pairs(spheres: list[SphereNode]) -> list[tuple[int, int]]:
    if len(spheres) < 2:
        return []

    centers = np.asarray([sphere.center for sphere in spheres], dtype=np.float32)
    radii = np.asarray([sphere.radius for sphere in spheres], dtype=np.float32)
    backend = os.environ.get("TCV52_COMPLEX_BACKEND", "cpu").strip().lower()

    if backend == "gpu" and len(spheres) >= 96:
        try:
            import cupy as cp  # type: ignore

            centers_gpu = cp.asarray(centers)
            radii_gpu = cp.asarray(radii)
            pairwise = cp.linalg.norm(centers_gpu[:, None, :] - centers_gpu[None, :, :], axis=-1)
            overlap = pairwise <= (radii_gpu[:, None] + radii_gpu[None, :])
            overlap = cp.triu(overlap, k=1)
            left_idx, right_idx = cp.where(overlap)
            pairs = np.stack([cp.asnumpy(left_idx), cp.asnumpy(right_idx)], axis=1)
            return [(int(left), int(right)) for left, right in pairs]
        except Exception:
            pass

    pairwise = np.linalg.norm(centers[:, None, :] - centers[None, :, :], axis=-1)
    overlap = np.triu(pairwise <= (radii[:, None] + radii[None, :]), k=1)
    return [(int(left), int(right)) for left, right in np.argwhere(overlap)]


def construct_full_nerve(map3d: Map3D, spheres: list[SphereNode]) -> tuple[NerveGeo, NerveContext]:
    raw_voxels = {sphere.id: _sphere_voxels(map3d, sphere, sphere.radius) for sphere in spheres}
    safe_voxels = {sphere.id: _sphere_voxels(map3d, sphere, safe_radius(map3d, sphere)) for sphere in spheres}

    edges: list[tuple[int, int]] = []
    for left_idx, right_idx in _candidate_edge_pairs(spheres):
        left = spheres[left_idx]
        right = spheres[right_idx]
        edge = stable_edge(left.id, right.id)
        if raw_voxels[left.id] & raw_voxels[right.id]:
            edges.append(edge)

    edge_graph = nx.Graph()
    edge_graph.add_nodes_from(sphere.id for sphere in spheres)
    edge_graph.add_edges_from(edges)

    triangles: list[tuple[int, int, int]] = []
    adjacency = {sphere.id: set(edge_graph.neighbors(sphere.id)) for sphere in spheres}
    for anchor in sorted(adjacency):
        higher_neighbors = sorted(node for node in adjacency[anchor] if node > anchor)
        for offset, left in enumerate(higher_neighbors[:-1]):
            common = adjacency[anchor] & adjacency[left]
            for right in sorted(node for node in common if node > left):
                overlap = raw_voxels[anchor] & raw_voxels[left] & raw_voxels[right]
                if overlap:
                    triangles.append((anchor, left, right))

    d1 = _boundary1(len(spheres), edges)
    d2, edge_index = _boundary2(edges, triangles)
    beta0 = len(spheres) - gf2_rank(d1)
    beta1 = len(edges) - gf2_rank(d1) - gf2_rank(d2)
    h1_basis = [
        [stable_edge(path[idx], path[idx + 1]) for idx in range(len(path) - 1)]
        for path in nx.cycle_basis(edge_graph)
    ]
    nerve = NerveGeo(
        simplices={
            0: [(sphere.id,) for sphere in spheres],
            1: edges,
            2: triangles,
        },
        betti=(int(beta0), int(beta1)),
        h1_basis=h1_basis,
    )
    return nerve, NerveContext(
        raw_voxels=raw_voxels,
        safe_voxels=safe_voxels,
        edge_index=edge_index,
        boundary1=d1,
        boundary2=d2,
        triangles=triangles,
    )


def cycle_is_nontrivial(edges: list[tuple[int, int]], context: NerveContext) -> bool:
    if not context.edge_index:
        return False
    chain = cycle_edge_vector(edges, context.edge_index)
    boundary_zero = not np.any((context.boundary1 @ chain) % 2)
    if not boundary_zero:
        return False
    return not gf2_contains_column_space(context.boundary2, chain)
