from __future__ import annotations

import argparse
import json
from pathlib import Path

from .map import available_scenes, generate_scene, save_map3d_npz
from .pipeline import run_pipeline_from_npz, run_scene, summarize_run


def main() -> None:
    parser = argparse.ArgumentParser(description="Core topology-audited safe corridor planner")
    subparsers = parser.add_subparsers(dest="command", required=True)

    list_parser = subparsers.add_parser("list-scenes", help="List built-in synthetic scenes")
    list_parser.add_argument("--json-out", type=Path)

    run_parser = subparsers.add_parser("run", help="Run one built-in synthetic scene")
    run_parser.add_argument("--scene", choices=available_scenes(), default="double_tunnel")
    run_parser.add_argument("--grid", type=int, default=48)
    run_parser.add_argument("--resolution", type=float, default=1.0)
    run_parser.add_argument("--clearance", type=float, default=2.0)
    run_parser.add_argument("--json-out", type=Path)

    external_parser = subparsers.add_parser("run-external", help="Run the planner on an external npz map")
    external_parser.add_argument("--npz", type=Path, required=True)
    external_parser.add_argument("--clearance", type=float, default=None)
    external_parser.add_argument("--json-out", type=Path)

    save_parser = subparsers.add_parser("save-scene", help="Export a built-in synthetic scene to a compressed npz map")
    save_parser.add_argument("--scene", choices=available_scenes(), default="single_tunnel")
    save_parser.add_argument("--out", type=Path, required=True)
    save_parser.add_argument("--grid", type=int, default=48)
    save_parser.add_argument("--resolution", type=float, default=1.0)
    save_parser.add_argument("--clearance", type=float, default=2.0)
    save_parser.add_argument("--json-out", type=Path)

    args = parser.parse_args()

    if args.command == "list-scenes":
        payload = {"scenes": available_scenes()}
    elif args.command == "run":
        run = run_scene(
            args.scene,
            grid_shape=(args.grid, args.grid, args.grid),
            resolution=args.resolution,
            clearance=args.clearance,
        )
        payload = summarize_run(run)
    elif args.command == "run-external":
        run = run_pipeline_from_npz(args.npz, clearance=args.clearance)
        payload = summarize_run(run)
    else:
        map3d = generate_scene(
            args.scene,
            grid_shape=(args.grid, args.grid, args.grid),
            resolution=args.resolution,
            clearance=args.clearance,
        )
        save_map3d_npz(map3d, args.out)
        payload = {
            "scene": args.scene,
            "output_npz": str(args.out),
            "shape": list(map3d.esdf_grid.shape),
            "resolution": map3d.resolution,
            "clearance": map3d.clearance_threshold,
        }

    content = json.dumps(payload, indent=2, sort_keys=True)
    if args.json_out:
        args.json_out.write_text(content, encoding="utf-8")
    print(content)


if __name__ == "__main__":
    main()
