from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

from tunnel_corridor_v52.map import load_map3d_npz, save_map3d_npz
from tunnel_corridor_v52.map.sim import generate_scene


def test_save_and_load_external_npz_roundtrip(tmp_path):
    map3d = generate_scene("single_tunnel", grid_shape=(32, 32, 32), resolution=1.0, clearance=2.0)
    target = tmp_path / "single_tunnel_external.npz"
    save_map3d_npz(map3d, target)
    loaded = load_map3d_npz(target, clearance=2.0)
    assert loaded.esdf_grid.shape == map3d.esdf_grid.shape
    assert loaded.metadata["scene_source"] == "external_npz"
    assert "audit_start" in loaded.metadata and "audit_goal" in loaded.metadata


def test_cli_run_and_run_external(tmp_path):
    map_path = tmp_path / "scene.npz"
    json_path = tmp_path / "run.json"
    external_json = tmp_path / "run_external.json"
    repo_src = str(Path(__file__).resolve().parents[1] / "src")
    env = os.environ.copy()
    env["PYTHONPATH"] = repo_src + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")

    subprocess.run(
        [
            sys.executable,
            "-m",
            "tunnel_corridor_v52.cli",
            "save-scene",
            "--scene",
            "single_tunnel",
            "--out",
            str(map_path),
        ],
        check=True,
        cwd=str(tmp_path),
        env=env,
    )

    subprocess.run(
        [
            sys.executable,
            "-m",
            "tunnel_corridor_v52.cli",
            "run",
            "--scene",
            "single_tunnel",
            "--json-out",
            str(json_path),
        ],
        check=True,
        cwd=str(tmp_path),
        env=env,
    )

    subprocess.run(
        [
            sys.executable,
            "-m",
            "tunnel_corridor_v52.cli",
            "run-external",
            "--npz",
            str(map_path),
            "--json-out",
            str(external_json),
        ],
        check=True,
        cwd=str(tmp_path),
        env=env,
    )

    run_payload = json.loads(json_path.read_text(encoding="utf-8"))
    external_payload = json.loads(external_json.read_text(encoding="utf-8"))
    assert run_payload["audit"]["success"] is True
    assert external_payload["audit"]["success"] is True
    assert external_payload["scene_source"] == "external_npz"
