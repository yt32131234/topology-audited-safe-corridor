from __future__ import annotations

import os
from itertools import islice
from itertools import product

import networkx as nx
import numpy as np
from skimage.measure import label

os.environ.setdefault("SYMPY_GROUND_TYPES", "python")

from sympy import Matrix
from sympy.matrices.normalforms import smith_normal_form

try:
    from skimage.morphology import skeletonize_3d
except ImportError:
    from skimage.morphology import skeletonize

    def skeletonize_3d(volume: np.ndarray) -> np.ndarray:
        return skeletonize(volume, method="lee")

from ..models import CutSurfaceBasis, Map3D, RegisteredSignatureLibrary, TopoReference
from ..utils import accumulate_signature, voxel_to_world, world_to_voxel


NEIGHBOR_OFFSETS = [
    offset
    for offset in product((-1, 0, 1), repeat=3)
    if offset != (0, 0, 0)
]
OFFICIAL_WITNESS_CYCLE_CAP = 4
OFFICIAL_PORTAL_PATH_CAP = 64


def _surface_from_edge(point_a: np.ndarray, point_b: np.ndarray, radius: float) -> np.ndarray:
    midpoint = (point_a + point_b) / 2.0
    direction = point_b - point_a
    norm = np.linalg.norm(direction)
    if norm == 0.0:
        direction = np.array([1.0, 0.0, 0.0], dtype=np.float32)
    else:
        direction = direction / norm
    return np.vstack(
        [
            midpoint.astype(np.float32),
            direction.astype(np.float32),
            np.asarray([radius, 0.0, 0.0], dtype=np.float32),
        ]
    )


def _safe_mask(map3d: Map3D) -> np.ndarray:
    return map3d.esdf_grid >= map3d.clearance_threshold


def _build_skeleton_graph(map3d: Map3D, safe_mask: np.ndarray) -> nx.Graph:
    skeleton = skeletonize_3d(safe_mask.astype(np.uint8)) > 0
    coords = [tuple(coord.tolist()) for coord in np.argwhere(skeleton)]
    graph = nx.Graph()
    for coord in coords:
        point = voxel_to_world(np.asarray(coord, dtype=np.int32)[None, :], map3d.resolution, map3d.origin)[0]
        graph.add_node(coord, point=point.astype(np.float32))
    coord_set = set(coords)
    for coord in coords:
        for dx, dy, dz in NEIGHBOR_OFFSETS:
            neighbor = (coord[0] + dx, coord[1] + dy, coord[2] + dz)
            if neighbor in coord_set and coord < neighbor:
                graph.add_edge(coord, neighbor)
    return graph


def _metadata_graph(map3d: Map3D) -> tuple[nx.Graph, dict[str, np.ndarray], list[tuple[str, str]]]:
    graph_nodes = {name: np.asarray(point, dtype=np.float32) for name, point in map3d.metadata.get("graph_nodes", {}).items()}
    graph_edges = list(map3d.metadata.get("graph_edges", []))
    graph = nx.Graph()
    for name, point in graph_nodes.items():
        graph.add_node(name, point=point)
    graph.add_edges_from(graph_edges)
    return graph, graph_nodes, graph_edges


def _nearest_node(graph: nx.Graph, point: np.ndarray) -> tuple[int, int, int]:
    return min(graph.nodes, key=lambda node: float(np.linalg.norm(graph.nodes[node]["point"] - point)))


def _compress_component(component: nx.Graph, anchor_nodes: set[tuple[int, int, int]]) -> nx.Graph:
    degrees = dict(component.degree())
    key_nodes = {node for node, degree in degrees.items() if degree != 2} | set(anchor_nodes)
    if not key_nodes:
        arbitrary = next(iter(component.nodes))
        key_nodes.add(arbitrary)
    compressed = nx.Graph()
    names = {node: f"n{idx}" for idx, node in enumerate(sorted(key_nodes))}
    for node, name in names.items():
        compressed.add_node(name, point=component.nodes[node]["point"], source=node)

    for node in key_nodes:
        for neighbor in component.neighbors(node):
            chain = [node, neighbor]
            previous = node
            current = neighbor
            while current not in key_nodes:
                next_nodes = [candidate for candidate in component.neighbors(current) if candidate != previous]
                if not next_nodes:
                    break
                previous, current = current, next_nodes[0]
                chain.append(current)
            if current == node:
                continue
            compressed.add_edge(names[node], names[current], path=chain)
    return compressed


def _compressed_skeleton_graph(map3d: Map3D, safe_mask: np.ndarray) -> tuple[nx.Graph, dict[str, np.ndarray], list[tuple[str, str]]]:
    graph = _build_skeleton_graph(map3d, safe_mask)
    if graph.number_of_nodes() == 0:
        return _metadata_graph(map3d)
    meta_nodes = map3d.metadata.get("graph_nodes", {})
    anchor_points = {name: np.asarray(point, dtype=np.float32) for name, point in meta_nodes.items()}
    anchor_raw_nodes = {_nearest_node(graph, point) for point in anchor_points.values()} if anchor_points else set()

    compressed = nx.Graph()
    for component_nodes in nx.connected_components(graph):
        component = graph.subgraph(component_nodes).copy()
        component_anchors = {node for node in anchor_raw_nodes if node in component}
        subgraph = _compress_component(component, component_anchors)
        compressed = nx.compose(compressed, subgraph)

    graph_nodes = {name: np.asarray(data["point"], dtype=np.float32) for name, data in compressed.nodes(data=True)}
    graph_edges = list(compressed.edges())
    if not graph_nodes:
        return _metadata_graph(map3d)
    return compressed, graph_nodes, graph_edges


def _reference_graph(map3d: Map3D, safe_mask: np.ndarray) -> tuple[nx.Graph, dict[str, np.ndarray], list[tuple[str, str]]]:
    metadata_graph, graph_nodes, graph_edges = _metadata_graph(map3d)
    if metadata_graph.number_of_nodes() > 0:
        return metadata_graph, graph_nodes, graph_edges
    return _compressed_skeleton_graph(map3d, safe_mask)


def _cycle_points(nodes: dict[str, np.ndarray], cycle: list[str]) -> np.ndarray:
    closed = cycle + [cycle[0]]
    return np.asarray([nodes[name] for name in closed], dtype=np.float32)


def _cycle_length(nodes: dict[str, np.ndarray], cycle: list[str]) -> float:
    points = _cycle_points(nodes, cycle)
    if len(points) < 2:
        return 0.0
    return float(np.linalg.norm(points[1:] - points[:-1], axis=1).sum())


def _representative_edge(cycle: list[str], used: set[tuple[str, str]]) -> tuple[str, str]:
    for left, right in zip(cycle, cycle[1:] + [cycle[0]]):
        edge = tuple(sorted((left, right)))
        if edge not in used:
            used.add(edge)
            return left, right
    left, right = cycle[0], cycle[1]
    used.add(tuple(sorted((left, right))))
    return left, right


def _portal_pairs(compressed_graph: nx.Graph, map3d: Map3D) -> list[tuple[str, str]]:
    source_portals = map3d.metadata.get("portal_pairs", [])
    source_points = map3d.metadata.get("graph_nodes", {})
    pairs: list[tuple[str, str]] = []
    for start_name, goal_name in source_portals:
        start_point = np.asarray(source_points[start_name], dtype=np.float32)
        goal_point = np.asarray(source_points[goal_name], dtype=np.float32)
        start = min(compressed_graph.nodes, key=lambda node: float(np.linalg.norm(compressed_graph.nodes[node]["point"] - start_point)))
        goal = min(compressed_graph.nodes, key=lambda node: float(np.linalg.norm(compressed_graph.nodes[node]["point"] - goal_point)))
        if start != goal:
            pairs.append((start, goal))
    return pairs


def _path_points(nodes: dict[str, np.ndarray], path: list[str]) -> np.ndarray:
    return np.asarray([nodes[name] for name in path], dtype=np.float32)


def _portal_signatures(
    graph: nx.Graph,
    nodes: dict[str, np.ndarray],
    portal_pairs: list[tuple[str, str]],
    surfaces: list[np.ndarray],
    max_paths_per_pair: int | None = None,
) -> list[tuple[int, ...]]:
    signatures: set[tuple[int, ...]] = set()
    weighted = nx.Graph()
    weighted.add_nodes_from(graph.nodes)
    for left, right in graph.edges():
        weighted.add_edge(left, right, weight=float(np.linalg.norm(nodes[left] - nodes[right])))
    for start, goal in portal_pairs:
        if max_paths_per_pair is None:
            iterator = nx.all_simple_paths(graph, start, goal, cutoff=max(2, graph.number_of_nodes()))
        else:
            iterator = islice(nx.shortest_simple_paths(weighted, start, goal, weight="weight"), max_paths_per_pair)
        for path in iterator:
            signatures.add(accumulate_signature(_path_points(nodes, path), surfaces))
    return sorted(signatures)


def _prune_portal_signatures(signatures: list[tuple[int, ...]], beta1: int) -> list[tuple[int, ...]]:
    if not signatures:
        return [tuple()]
    ordered = sorted(
        {tuple(signature) for signature in signatures},
        key=lambda signature: (
            0 if not any(signature) else 1,
            sum(abs(int(value)) for value in signature),
            signature,
        ),
    )
    if beta1 <= 0:
        return [ordered[0]]
    limit = min(len(ordered), beta1 + 1)
    zero = [signature for signature in ordered if not any(signature)]
    non_zero = [signature for signature in ordered if any(signature)]
    chosen: list[tuple[int, ...]] = []
    if zero:
        chosen.append(zero[0])
    chosen.extend(non_zero[: max(0, limit - len(chosen))])
    return chosen if chosen else [ordered[0]]


def build_topo_reference(map3d: Map3D) -> TopoReference:
    safe_mask = _safe_mask(map3d)
    component_labels = label(safe_mask, connectivity=safe_mask.ndim)
    beta0 = int(component_labels.max())

    compressed_graph, graph_nodes, graph_edges = _reference_graph(map3d, safe_mask)
    raw_beta1 = int(compressed_graph.number_of_edges() - compressed_graph.number_of_nodes() + nx.number_connected_components(compressed_graph))
    cycles = [cycle for cycle in nx.cycle_basis(compressed_graph) if len(cycle) >= 3]
    if map3d.metadata.get("scene_source") == "subt_tsv_official" and len(cycles) > OFFICIAL_WITNESS_CYCLE_CAP:
        cycles = sorted(cycles, key=lambda cycle: (_cycle_length(graph_nodes, cycle), tuple(cycle)))[:OFFICIAL_WITNESS_CYCLE_CAP]
        map3d.metadata["reference_beta_truncated"] = {
            "original_beta1": raw_beta1,
            "used_beta1": len(cycles),
            "cycle_cap": OFFICIAL_WITNESS_CYCLE_CAP,
        }
    tree_edges = {tuple(sorted(edge)) for edge in nx.minimum_spanning_tree(compressed_graph).edges()}
    selected_cycle_edges_unsorted: list[tuple[str, str]] = []
    used_cycle_edges: set[tuple[str, str]] = set()
    for cycle in cycles:
        cycle_edges = [tuple(sorted((left, right))) for left, right in zip(cycle, cycle[1:] + [cycle[0]])]
        chosen = next(
            (
                edge
                for edge in cycle_edges
                if edge not in tree_edges and edge not in used_cycle_edges
            ),
            cycle_edges[0] if cycle_edges else None,
        )
        if chosen is not None:
            used_cycle_edges.add(chosen)
            selected_cycle_edges_unsorted.append(chosen)
    selected_cycle_edges = sorted(selected_cycle_edges_unsorted)
    map3d.metadata["selected_cycle_edges"] = selected_cycle_edges
    beta1 = len(cycles)
    witness_cycles = [_cycle_points(graph_nodes, cycle) for cycle in cycles]

    used_edges: set[tuple[str, str]] = set()
    surfaces = []
    for cycle in cycles:
        left, right = _representative_edge(cycle, used_edges)
        surfaces.append(_surface_from_edge(graph_nodes[left], graph_nodes[right], radius=3.0 * map3d.resolution))

    witness_sigs = [accumulate_signature(cycle_points, surfaces) for cycle_points in witness_cycles]
    if witness_sigs:
        intersection_matrix = np.asarray(witness_sigs, dtype=int)
    else:
        intersection_matrix = np.zeros((0, 0), dtype=int)

    smith_rank = 0
    if intersection_matrix.size:
        smith = smith_normal_form(Matrix(intersection_matrix))
        smith_rank = sum(int(smith[idx, idx] != 0) for idx in range(min(smith.rows, smith.cols)))
    if beta1 and smith_rank != beta1:
        raise ValueError(f"Reference signature matrix is not independent: smith_rank={smith_rank}, beta1={beta1}")

    portal_pairs = _portal_pairs(compressed_graph, map3d)
    portal_path_cap = OFFICIAL_PORTAL_PATH_CAP if map3d.metadata.get("scene_source") == "subt_tsv_official" else None
    portal_path_sigs = _prune_portal_signatures(
        _portal_signatures(compressed_graph, graph_nodes, portal_pairs, surfaces, max_paths_per_pair=portal_path_cap),
        beta1=beta1,
    )
    all_sigs = set(portal_path_sigs) | set(witness_sigs)
    if not all_sigs:
        all_sigs.add(tuple())
        portal_path_sigs = [tuple()]

    cut_basis = CutSurfaceBasis(
        surfaces=surfaces,
        witness_cycles=witness_cycles,
        intersection_matrix=intersection_matrix,
    )
    signature_library = RegisteredSignatureLibrary(
        witness_sigs=witness_sigs,
        portal_path_sigs=portal_path_sigs,
        all_sigs=all_sigs,
    )
    map3d.metadata["component_labels"] = component_labels
    map3d.metadata["reference_graph"] = compressed_graph
    return TopoReference(
        beta=(beta0, beta1),
        witness_cycles=witness_cycles,
        cut_surfaces=cut_basis,
        signature_library=signature_library,
        realizations=None,
        graph_nodes=graph_nodes,
        graph_edges=graph_edges,
        portal_pairs=portal_pairs,
        portal_points={name: graph_nodes[name].copy() for pair in portal_pairs for name in pair},
    )
