from __future__ import annotations

import math
import time
from itertools import islice

import networkx as nx
import numpy as np

from ..models import CorridorQuery, CorridorResult, PathQualityMetrics, PlanGraph, SafetyCertificate, SphereNode, TopoReference, WitnessRealization
from ..utils import SQRT3_OVER_2, accumulate_signature, majority_label, sample_polyline, stable_edge, world_to_voxel
from .complex import construct_full_nerve, safe_radius


def standard_lift(
    nodes: dict[int, SphereNode],
    chain: list[int],
    resolution: float,
    safety_margin: float,
    start: np.ndarray | None = None,
    goal: np.ndarray | None = None,
) -> np.ndarray:
    if not chain:
        return np.zeros((0, 3), dtype=np.float32)
    first_center = nodes[chain[0]].center
    last_center = nodes[chain[-1]].center
    points = [first_center if start is None else start.astype(np.float32)]
    for left_id, right_id in zip(chain[:-1], chain[1:]):
        left = nodes[left_id]
        right = nodes[right_id]
        left_safe = max(0.0, left.radius - SQRT3_OVER_2 * resolution - safety_margin)
        right_safe = max(0.0, right.radius - SQRT3_OVER_2 * resolution - safety_margin)
        denom = left_safe + right_safe
        if denom <= 0.0:
            midpoint = 0.5 * (left.center + right.center)
        else:
            midpoint = (right_safe * left.center + left_safe * right.center) / denom
        points.append(midpoint.astype(np.float32))
    points.append(last_center if goal is None else goal.astype(np.float32))
    return np.asarray(points, dtype=np.float32)


def chain_signature(
    nodes: dict[int, SphereNode],
    chain: list[int],
    surfaces: list[np.ndarray],
    resolution: float,
    safety_margin: float,
    start: np.ndarray | None = None,
    goal: np.ndarray | None = None,
) -> tuple[int, ...]:
    if not chain:
        return tuple()
    polyline = standard_lift(nodes, chain, resolution=resolution, safety_margin=safety_margin, start=start, goal=goal)
    return accumulate_signature(polyline, surfaces)


def _lift_length(polyline: np.ndarray) -> float:
    if len(polyline) < 2:
        return 0.0
    deltas = polyline[1:] - polyline[:-1]
    return float(np.linalg.norm(deltas, axis=1).sum())


def _turn_angles_deg(polyline: np.ndarray) -> np.ndarray:
    if len(polyline) < 3:
        return np.zeros(0, dtype=np.float32)
    deltas = polyline[1:] - polyline[:-1]
    lengths = np.linalg.norm(deltas, axis=1)
    valid = lengths > 1e-8
    if valid.sum() < 2:
        return np.zeros(0, dtype=np.float32)
    unit = deltas[valid] / lengths[valid, None]
    dots = np.sum(unit[:-1] * unit[1:], axis=1)
    dots = np.clip(dots, -1.0, 1.0)
    return np.degrees(np.arccos(dots)).astype(np.float32)


def _safe_overlap_rate(plan_graph: PlanGraph, path: list[int]) -> float:
    if len(path) < 2:
        return 1.0
    satisfied = 0
    for left_id, right_id in zip(path[:-1], path[1:]):
        left = plan_graph.nodes[left_id]
        right = plan_graph.nodes[right_id]
        distance = float(np.linalg.norm(left.center - right.center))
        if distance < max(0.0, left.radius - SQRT3_OVER_2 * plan_graph.resolution - plan_graph.safety_margin) + max(
            0.0, right.radius - SQRT3_OVER_2 * plan_graph.resolution - plan_graph.safety_margin
        ):
            satisfied += 1
    return satisfied / max(1, len(path) - 1)


def _sample_path_clearances(plan_graph: PlanGraph, polyline: np.ndarray) -> np.ndarray:
    if plan_graph.esdf_grid is None or plan_graph.origin is None or len(polyline) == 0:
        return np.zeros(0, dtype=np.float32)
    samples: list[np.ndarray] = []
    step = max(0.5 * plan_graph.resolution, 0.5)
    for left, right in zip(polyline[:-1], polyline[1:]):
        segment = sample_polyline(np.asarray([left, right], dtype=np.float32), step=step)
        samples.extend(segment[:-1])
    samples.append(polyline[-1])
    values: list[float] = []
    grid_shape = np.asarray(plan_graph.esdf_grid.shape) - 1
    for point in samples:
        voxel = world_to_voxel(point, plan_graph.resolution, plan_graph.origin)
        voxel = np.clip(voxel, [0, 0, 0], grid_shape)
        values.append(float(plan_graph.esdf_grid[tuple(voxel)]))
    return np.asarray(values, dtype=np.float32)


def _edge_cost(plan_graph: PlanGraph, left_id: int, right_id: int) -> float:
    left = plan_graph.nodes[left_id]
    right = plan_graph.nodes[right_id]
    distance = float(np.linalg.norm(left.center - right.center))
    edge_clearance = min(
        max(0.0, left.radius - SQRT3_OVER_2 * plan_graph.resolution - plan_graph.safety_margin),
        max(0.0, right.radius - SQRT3_OVER_2 * plan_graph.resolution - plan_graph.safety_margin),
    )
    clearance_floor = max(0.25 * plan_graph.clearance_threshold, 0.5 * plan_graph.resolution, 1e-6)
    clearance_bias = max(plan_graph.clearance_threshold, clearance_floor)
    return distance * (1.0 + clearance_bias / max(edge_clearance, clearance_floor))


def _quality_metrics(
    plan_graph: PlanGraph,
    path: list[int],
    corridor_spheres: list[tuple[np.ndarray, float]],
    polyline: np.ndarray,
    signature: tuple[int, ...],
) -> PathQualityMetrics:
    safe_radii = np.asarray([radius for _, radius in corridor_spheres], dtype=np.float32)
    sampled_clearances = _sample_path_clearances(plan_graph, polyline)
    clearance_values = sampled_clearances if sampled_clearances.size else safe_radii
    lift_length = _lift_length(polyline)
    straight = float(np.linalg.norm(polyline[-1] - polyline[0])) if len(polyline) >= 2 else 0.0
    angles_deg = _turn_angles_deg(polyline)
    angles_rad = np.radians(angles_deg.astype(np.float64))
    curvature_proxy = float(angles_rad.sum() / max(lift_length, 1e-8))
    return PathQualityMetrics(
        lift_length=lift_length,
        detour_ratio=float(lift_length / max(straight, 1e-8)) if straight > 0.0 else 1.0,
        min_clearance=float(clearance_values.min()) if clearance_values.size else 0.0,
        mean_clearance=float(clearance_values.mean()) if clearance_values.size else 0.0,
        p05_clearance=float(np.percentile(clearance_values, 5.0)) if clearance_values.size else 0.0,
        max_turn_deg=float(angles_deg.max()) if angles_deg.size else 0.0,
        mean_turn_deg=float(angles_deg.mean()) if angles_deg.size else 0.0,
        curvature_proxy=curvature_proxy,
        smoothness_proxy=float(angles_deg.std()) if angles_deg.size else 0.0,
        energy_proxy=float(lift_length * (1.0 + curvature_proxy)),
        safe_overlap_rate=_safe_overlap_rate(plan_graph, path),
        certificate_signature=signature,
    )


def _sphere_label(map3d_labels: np.ndarray | None, voxel_ids: set[int], shape: tuple[int, int, int]) -> int:
    if map3d_labels is None or not voxel_ids:
        return 0
    coords = np.asarray(np.unravel_index(np.asarray(sorted(voxel_ids), dtype=np.int64), shape)).T
    values = [int(map3d_labels[tuple(coord)]) for coord in coords]
    return majority_label(values)


def build_plan_graph(map3d, topo_ref: TopoReference, spheres: list[SphereNode], realizations: list[WitnessRealization]) -> PlanGraph:
    nerve, context = construct_full_nerve(map3d, spheres)
    labels_grid = map3d.metadata.get("component_labels")
    nodes = {sphere.id: sphere for sphere in spheres}
    witness_chain_edges = {
        stable_edge(left_id, right_id)
        for realization in realizations
        for left_id, right_id in zip(realization.sphere_chain[:-1], realization.sphere_chain[1:])
    }
    protected_edges = set(witness_chain_edges) | set(topo_ref.protected_edges)
    sphere_labels = {
        sphere.id: _sphere_label(labels_grid, context.safe_voxels[sphere.id], map3d.esdf_grid.shape)
        for sphere in spheres
    }
    safe_edges: set[tuple[int, int]] = set()
    veto_set: set[tuple[int, int]] = set()
    edge_signatures: dict[tuple[int, int], tuple[int, ...]] = {}
    for edge in nerve.simplices.get(1, []):
        left = nodes[edge[0]]
        right = nodes[edge[1]]
        distance = float(np.linalg.norm(left.center - right.center))
        if distance < safe_radius(map3d, left) + safe_radius(map3d, right):
            safe_edges.add(edge)
        else:
            veto_set.add(edge)
            continue
        if sphere_labels[left.id] and sphere_labels[right.id] and sphere_labels[left.id] != sphere_labels[right.id] and edge not in protected_edges:
            veto_set.add(edge)
        edge_signatures[edge] = accumulate_signature(
            np.asarray([left.center, right.center], dtype=np.float32),
            topo_ref.cut_surfaces.surfaces,
        )

    final_edges = {edge for edge in safe_edges if edge not in veto_set or edge in protected_edges}
    band_constraints: dict[int, set[int]] = {}
    for sphere in spheres:
        band_constraints.setdefault(sphere.region_id, set()).add(sphere.id)
    return PlanGraph(
        nodes=nodes,
        edges=final_edges,
        veto_set=veto_set,
        band_constraints=band_constraints,
        witness_chain_edges=witness_chain_edges,
        protected_edges=protected_edges,
        edge_signatures=edge_signatures,
        resolution=map3d.resolution,
        safety_margin=map3d.safety_margin,
        clearance_threshold=map3d.clearance_threshold,
        origin=map3d.origin.copy(),
        esdf_grid=map3d.esdf_grid,
    )


def _locate_node(plan_graph: PlanGraph, point: np.ndarray) -> int:
    containing: list[tuple[float, int]] = []
    closest: tuple[float, int] | None = None
    for sphere in plan_graph.nodes.values():
        radius = max(0.0, sphere.radius - SQRT3_OVER_2 * plan_graph.resolution - plan_graph.safety_margin)
        distance = float(np.linalg.norm(point - sphere.center))
        gap = max(0.0, distance - radius)
        if distance <= radius:
            containing.append((distance, sphere.id))
        if closest is None or gap < closest[0]:
            closest = (gap, sphere.id)
    if containing:
        return min(containing)[1]
    if closest is None:
        raise ValueError("PlanGraph has no nodes.")
    return closest[1]


def _graph_from_plan(plan_graph: PlanGraph) -> nx.Graph:
    graph = nx.Graph()
    graph.add_nodes_from(plan_graph.nodes)
    for left_id, right_id in plan_graph.edges:
        graph.add_edge(left_id, right_id, weight=_edge_cost(plan_graph, left_id, right_id))
    return graph


def _shortcut_path(
    plan_graph: PlanGraph,
    topo_ref: TopoReference,
    path: list[int],
    start: np.ndarray,
    goal: np.ndarray,
    expected_signature: tuple[int, ...] | None,
) -> list[int]:
    if len(path) < 3:
        return path
    edges = set(plan_graph.edges)
    shortened = list(path)
    changed = True
    while changed and len(shortened) >= 3:
        changed = False
        left_idx = 0
        while left_idx < len(shortened) - 2 and not changed:
            for right_idx in range(len(shortened) - 1, left_idx + 1, -1):
                if right_idx <= left_idx + 1:
                    continue
                if stable_edge(shortened[left_idx], shortened[right_idx]) not in edges:
                    continue
                candidate = shortened[: left_idx + 1] + shortened[right_idx:]
                if expected_signature is not None:
                    signature = chain_signature(
                        plan_graph.nodes,
                        candidate,
                        topo_ref.cut_surfaces.surfaces,
                        resolution=plan_graph.resolution,
                        safety_margin=plan_graph.safety_margin,
                        start=start,
                        goal=goal,
                    )
                    if signature != expected_signature:
                        continue
                shortened = candidate
                changed = True
                break
            left_idx += 1
    return shortened


def _registered_signature_path(graph: nx.Graph, topo_ref: TopoReference, start_id: int, goal_id: int, signature: tuple[int, ...]) -> list[int] | None:
    for realization in topo_ref.registered_paths:
        if not realization.is_valid or realization.signature != signature or not realization.sphere_chain:
            continue
        chain = list(realization.sphere_chain)
        try:
            prefix = [start_id] if chain[0] == start_id else nx.shortest_path(graph, start_id, chain[0], weight="weight")
            suffix = [goal_id] if chain[-1] == goal_id else nx.shortest_path(graph, chain[-1], goal_id, weight="weight")
        except nx.NetworkXNoPath:
            continue
        return prefix[:-1] + chain + suffix[1:]
    return None


def query_corridor(plan_graph: PlanGraph, topo_ref: TopoReference, query: CorridorQuery) -> CorridorResult:
    started = time.perf_counter()
    graph = _graph_from_plan(plan_graph)
    start_id = _locate_node(plan_graph, query.start)
    goal_id = _locate_node(plan_graph, query.goal)
    if query.mode == "best_safe_path" or query.topo_signature is None:
        path = nx.shortest_path(graph, start_id, goal_id, weight="weight")
    else:
        path = _registered_signature_path(graph, topo_ref, start_id, goal_id, query.topo_signature)
        if path is not None:
            registered_signature = chain_signature(
                plan_graph.nodes,
                path,
                topo_ref.cut_surfaces.surfaces,
                resolution=plan_graph.resolution,
                safety_margin=plan_graph.safety_margin,
                start=query.start,
                goal=query.goal,
            )
            if registered_signature != query.topo_signature:
                path = None
        for candidate in [] if path is not None else islice(nx.shortest_simple_paths(graph, start_id, goal_id, weight="weight"), 128):
            signature = chain_signature(
                plan_graph.nodes,
                list(candidate),
                topo_ref.cut_surfaces.surfaces,
                resolution=plan_graph.resolution,
                safety_margin=plan_graph.safety_margin,
                start=query.start,
                goal=query.goal,
            )
            if signature == query.topo_signature:
                path = list(candidate)
                break
        if path is None:
            raise ValueError(f"No plan-graph path matches signature {query.topo_signature}.")

    expected_signature = None if query.mode == "best_safe_path" or query.topo_signature is None else query.topo_signature
    path = _shortcut_path(
        plan_graph,
        topo_ref,
        list(path),
        start=query.start,
        goal=query.goal,
        expected_signature=expected_signature,
    )

    polyline = standard_lift(
        plan_graph.nodes,
        path,
        resolution=plan_graph.resolution,
        safety_margin=plan_graph.safety_margin,
        start=query.start,
        goal=query.goal,
    )
    signature = chain_signature(
        plan_graph.nodes,
        path,
        topo_ref.cut_surfaces.surfaces,
        resolution=plan_graph.resolution,
        safety_margin=plan_graph.safety_margin,
        start=query.start,
        goal=query.goal,
    )
    corridor_spheres = []
    safe_radii = []
    for node_id in path:
        sphere = plan_graph.nodes[node_id]
        node_safe_radius = max(0.0, sphere.radius - SQRT3_OVER_2 * plan_graph.resolution - plan_graph.safety_margin)
        corridor_spheres.append((sphere.center.copy(), node_safe_radius))
        safe_radii.append((node_id, node_safe_radius))
    path_length = _lift_length(polyline)
    min_radius = min(radius for _, radius in safe_radii)
    bottlenecks = [node_id for node_id, radius in safe_radii if math.isclose(radius, min_radius, rel_tol=1e-6, abs_tol=1e-6)]
    certificate = SafetyCertificate(
        uniform_clearance_guarantee=min_radius,
        path_bottleneck_clearance=min_radius,
        topo_signature=signature,
        bottleneck_spheres=bottlenecks,
        discretization_error=SQRT3_OVER_2 * plan_graph.resolution + plan_graph.safety_margin,
    )
    quality_metrics = _quality_metrics(plan_graph, path, corridor_spheres, polyline, signature)
    quality_metrics.query_latency_ms = (time.perf_counter() - started) * 1000.0
    return CorridorResult(
        sphere_path=list(path),
        corridor_spheres=corridor_spheres,
        certificate=certificate,
        path_length=path_length,
        lift_polyline=polyline,
        quality_metrics=quality_metrics,
    )
